/**
 * EngineValidator.ts — Phase 5: Stability & Engine Hardening
 *
 * - NaN guard: validates all PoseMeshInput values
 * - Vertex explosion detection: auto-reset if any vertex far from center
 * - Performance telemetry with rolling statistics
 */

import type { PoseMeshInput } from './interfaces/IMeshLayer';

// ── NaN Guard ─────────────────────────────────────────────────

/**
 * Validate all fields in PoseMeshInput.
 * Returns false if any value is NaN or Infinity.
 */
export function validatePoseInput(input: PoseMeshInput): boolean {
  const vals = [
    input.leftShoulder.x, input.leftShoulder.y,
    input.rightShoulder.x, input.rightShoulder.y,
    input.leftHip.x, input.leftHip.y,
    input.rightHip.x, input.rightHip.y,
    input.opacity,
  ];

  // Optional fields
  if (input.leftElbow) {
    vals.push(input.leftElbow.x, input.leftElbow.y);
  }
  if (input.rightElbow) {
    vals.push(input.rightElbow.x, input.rightElbow.y);
  }
  if (input.noseY !== undefined) vals.push(input.noseY);
  if (input.yawCompression !== undefined) vals.push(input.yawCompression);
  if (input.torsoPitchScale !== undefined) vals.push(input.torsoPitchScale);
  if (input.collarY !== undefined) vals.push(input.collarY);
  if (input.depthWidthScale !== undefined) vals.push(input.depthWidthScale);

  for (let i = 0; i < vals.length; i++) {
    if (!isFinite(vals[i])) return false; // catches NaN and Infinity
  }
  return true;
}

// ── Vertex Explosion Detector ─────────────────────────────────

/**
 * Check if any vertex in dstBuf has exploded beyond reasonable bounds.
 * Returns true if mesh needs reset.
 */
export function detectVertexExplosion(
  dstBuf: Float32Array,
  totalVerts: number,
  canvasWidth: number,
  canvasHeight: number,
): boolean {
  const maxDist = Math.max(canvasWidth, canvasHeight) * 1.5;
  const cx = canvasWidth * 0.5;
  const cy = canvasHeight * 0.5;

  for (let i = 0; i < totalVerts; i++) {
    const bi = i * 2;
    const dx = dstBuf[bi] - cx;
    const dy = dstBuf[bi + 1] - cy;
    if (dx * dx + dy * dy > maxDist * maxDist) {
      return true; // vertex exploded
    }
  }
  return false;
}

// ── Performance Telemetry ─────────────────────────────────────

export interface EngineTelemetry {
  /** Rolling average FPS (last 60 frames) */
  fpsAvg: number;
  /** Min FPS in window */
  fpsMin: number;
  /** Max FPS in window */
  fpsMax: number;
  /** Frame time variance (ms²) */
  frameVariance: number;
  /** Number of density switches since start */
  densitySwitchCount: number;
  /** Recent density switch log (last 10) */
  densitySwitchLog: { timestamp: number; from: number; to: number }[];
  /** Number of invalid frames (mesh rejected) since start */
  invalidFrameCount: number;
  /** Number of NaN-rejected frames */
  nanFrameCount: number;
  /** Number of vertex explosion resets */
  explosionResetCount: number;
}

export class TelemetryTracker {
  private frameTimes: number[] = [];
  private readonly WINDOW = 60;

  private _densitySwitchCount = 0;
  private _densitySwitchLog: { timestamp: number; from: number; to: number }[] = [];
  private _invalidFrameCount = 0;
  private _nanFrameCount = 0;
  private _explosionResetCount = 0;

  /** Record a frame time */
  recordFrame(frameTimeMs: number): void {
    this.frameTimes.push(frameTimeMs);
    if (this.frameTimes.length > this.WINDOW) {
      this.frameTimes.shift();
    }
  }

  /** Record a density switch */
  recordDensitySwitch(from: number, to: number): void {
    this._densitySwitchCount++;
    this._densitySwitchLog.push({ timestamp: Date.now(), from, to });
    if (this._densitySwitchLog.length > 10) this._densitySwitchLog.shift();
  }

  /** Record an invalid mesh frame */
  recordInvalidFrame(): void { this._invalidFrameCount++; }

  /** Record a NaN-rejected frame */
  recordNaNFrame(): void { this._nanFrameCount++; }

  /** Record a vertex explosion reset */
  recordExplosionReset(): void { this._explosionResetCount++; }

  /** Get current telemetry snapshot */
  get snapshot(): EngineTelemetry {
    const ft = this.frameTimes;
    if (ft.length === 0) {
      return {
        fpsAvg: 0, fpsMin: 0, fpsMax: 0, frameVariance: 0,
        densitySwitchCount: this._densitySwitchCount,
        densitySwitchLog: [...this._densitySwitchLog],
        invalidFrameCount: this._invalidFrameCount,
        nanFrameCount: this._nanFrameCount,
        explosionResetCount: this._explosionResetCount,
      };
    }

    let sum = 0, min = Infinity, max = 0;
    for (let i = 0; i < ft.length; i++) {
      sum += ft[i];
      if (ft[i] < min) min = ft[i];
      if (ft[i] > max) max = ft[i];
    }
    const avgMs = sum / ft.length;

    // Variance
    let varSum = 0;
    for (let i = 0; i < ft.length; i++) {
      const d = ft[i] - avgMs;
      varSum += d * d;
    }

    return {
      fpsAvg: avgMs > 0 ? Math.round(1000 / avgMs) : 0,
      fpsMin: max > 0 ? Math.round(1000 / max) : 0, // max frameTime = min FPS
      fpsMax: min > 0 ? Math.round(1000 / min) : 0,
      frameVariance: Math.round(varSum / ft.length * 100) / 100,
      densitySwitchCount: this._densitySwitchCount,
      densitySwitchLog: [...this._densitySwitchLog],
      invalidFrameCount: this._invalidFrameCount,
      nanFrameCount: this._nanFrameCount,
      explosionResetCount: this._explosionResetCount,
    };
  }

  reset(): void {
    this.frameTimes.length = 0;
    this._densitySwitchCount = 0;
    this._densitySwitchLog.length = 0;
    this._invalidFrameCount = 0;
    this._nanFrameCount = 0;
    this._explosionResetCount = 0;
  }
}
