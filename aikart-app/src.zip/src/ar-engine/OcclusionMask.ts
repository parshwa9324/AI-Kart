/**
 * OcclusionMask.ts — Lightweight Arm Occlusion
 *
 * Phase 4: Landmark-based arm occlusion, no segmentation ML.
 *
 * Detection: wrist crosses torso center → arm crossing body
 * Mask: rectangular region from wrist to elbow, drawn as clipping exclusion
 * Auto-disable: if unreliable (>50% of frames in 2s), disable
 */

export interface OcclusionRegion {
  /** Left edge of occlusion rectangle (canvas px) */
  x: number;
  /** Top edge */
  y: number;
  /** Width */
  w: number;
  /** Height */
  h: number;
  /** Which side is occluding ('left' arm crossing to right, or vice versa) */
  side: 'left' | 'right';
}

export class OcclusionMask {
  private triggerCount = 0;
  private frameCount = 0;
  private readonly WINDOW_FRAMES = 60; // ~2 seconds at 30fps
  private disabled = false;

  private readonly DISABLE_THRESHOLD = 0.5; // disable if >50% of frames

  // Object pool to avoid allocations
  private pool: OcclusionRegion[] = [
    { x: 0, y: 0, w: 0, h: 0, side: 'left' },
    { x: 0, y: 0, w: 0, h: 0, side: 'right' },
  ];
  private activeRegions: OcclusionRegion[] = [];

  /**
   * Detect if either wrist crosses the torso center line.
   * Returns occlusion regions to carve out from garment, or empty array.
   *
   * @param shoulderMidX Torso center X (canvas px)
   * @param shoulderDist Shoulder distance (canvas px) for sizing
   * @param leftWrist Left wrist position (canvas px) or undefined
   * @param rightWrist Right wrist position (canvas px) or undefined
   * @param leftWristConf Left wrist visibility (0-1)
   * @param rightWristConf Right wrist visibility (0-1)
   * @param leftElbow Left elbow position
   * @param rightElbow Right elbow position
   */
  detect(
    shoulderMidX: number,
    shoulderDist: number,
    leftWrist?: { x: number; y: number },
    rightWrist?: { x: number; y: number },
    leftWristConf = 0,
    rightWristConf = 0,
    leftElbow?: { x: number; y: number },
    rightElbow?: { x: number; y: number },
  ): OcclusionRegion[] {
    // BUG 3 safety: reject invalid inputs that cause downstream crashes
    if (!shoulderDist || shoulderDist < 10 || !isFinite(shoulderMidX)) return [];

    this.frameCount++;

    // Check if auto-disabled
    if (this.disabled) return [];

    // Auto-disable check every WINDOW_FRAMES
    if (this.frameCount >= this.WINDOW_FRAMES) {
      if (this.triggerCount / this.frameCount > this.DISABLE_THRESHOLD) {
        this.disabled = true;
        return [];
      }
      this.frameCount = 0;
      this.triggerCount = 0;
    }



    // Reset active regions
    this.activeRegions.length = 0;

    const halfShoulder = shoulderDist * 0.5;
    const maskW = shoulderDist * 0.15;

    // Left wrist crossing to right side of body (mirrored screen left)
    if (leftWrist && leftWristConf > 0.5) {
      if (leftWrist.x < shoulderMidX - halfShoulder * 0.1) {
        // Wrist has crossed past center
        const anchor = leftElbow ?? leftWrist;
        const minX = Math.min(leftWrist.x, anchor.x);
        const maxX = Math.max(leftWrist.x, anchor.x);
        const minY = Math.min(leftWrist.y, anchor.y);
        const maxY = Math.max(leftWrist.y, anchor.y);

        const reg = this.pool[0];
        reg.x = minX - maskW * 0.5;
        reg.y = minY - maskW * 0.5;
        reg.w = Math.max(maxX - minX, maskW) + maskW;
        reg.h = Math.max(maxY - minY, maskW) + maskW;
        reg.side = 'left';
        this.activeRegions.push(reg);

        this.triggerCount++;
      }
    }

    // Right wrist crossing to left side of body (mirrored screen right)
    if (rightWrist && rightWristConf > 0.5) {
      if (rightWrist.x > shoulderMidX + halfShoulder * 0.1) {
        const anchor = rightElbow ?? rightWrist;
        const minX = Math.min(rightWrist.x, anchor.x);
        const maxX = Math.max(rightWrist.x, anchor.x);
        const minY = Math.min(rightWrist.y, anchor.y);
        const maxY = Math.max(rightWrist.y, anchor.y);

        const reg = this.pool[1];
        reg.x = minX - maskW * 0.5;
        reg.y = minY - maskW * 0.5;
        reg.w = Math.max(maxX - minX, maskW) + maskW;
        reg.h = Math.max(maxY - minY, maskW) + maskW;
        reg.side = 'right';
        this.activeRegions.push(reg);

        this.triggerCount++;
      }
    }

    return this.activeRegions;
  }

  /** Force re-enable (e.g., after garment change) */
  reset(): void {
    this.disabled = false;
    this.triggerCount = 0;
    this.frameCount = 0;
  }

  get isDisabled(): boolean {
    return this.disabled;
  }
}
