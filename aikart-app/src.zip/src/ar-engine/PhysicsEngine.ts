import * as THREE from 'three';

/**
 * Ensures Ammo is loaded asynchronously
 */
export async function initAmmo(): Promise<typeof Ammo> {
    if (typeof window !== 'undefined' && window.Ammo) {
        if (typeof window.Ammo === 'function') {
            const ammoReady = await window.Ammo();
            window.Ammo = ammoReady;
        }
        return window.Ammo;
    }

    return new Promise((resolve) => {
        const script = document.createElement('script');
        script.src = '/ammo/ammo.wasm.js';
        script.onload = async () => {
            if (typeof window.Ammo === 'function') {
                const ammoReady = await window.Ammo();
                window.Ammo = ammoReady;
                resolve(ammoReady);
            } else {
                resolve(window.Ammo);
            }
        };
        document.head.appendChild(script);
    });
}

export class PhysicsEngine {
    private physicsWorld: Ammo.btSoftBodyRigidBodyDynamicsWorld | null = null;
    private dispatcher: Ammo.btCollisionDispatcher | null = null;
    private broadphase: Ammo.btDbvtBroadphase | null = null;
    private solver: Ammo.btSequentialImpulseConstraintSolver | null = null;
    private softBodySolver: Ammo.btDefaultSoftBodySolver | null = null;
    private collisionConfiguration: Ammo.btDefaultCollisionConfiguration | null = null;

    // Internal lists to sync visuals to physics
    private rigidBodies: { mesh: THREE.Mesh | THREE.Object3D, body: Ammo.btRigidBody }[] = [];
    private softBodies: { mesh: THREE.Mesh | THREE.Object3D, body: Ammo.btSoftBody }[] = [];

    // Temp variables for math to prevent GC spikes
    private tempTransform: Ammo.btTransform | null = null;
    private tempVec: Ammo.btVector3 | null = null;
    private tempQuat: Ammo.btQuaternion | null = null;

    private isReady = false;

    async init() {
        if (this.isReady) return;
        const ammo = await initAmmo();

        this.collisionConfiguration = new ammo.btDefaultCollisionConfiguration();
        this.dispatcher = new ammo.btCollisionDispatcher(this.collisionConfiguration);
        this.broadphase = new ammo.btDbvtBroadphase();
        this.solver = new ammo.btSequentialImpulseConstraintSolver();
        this.softBodySolver = new ammo.btDefaultSoftBodySolver();

        this.physicsWorld = new ammo.btSoftBodyRigidBodyDynamicsWorld(
            this.dispatcher,
            this.broadphase,
            this.solver,
            this.collisionConfiguration,
            this.softBodySolver
        );

        const gravity = new ammo.btVector3(0, -9.8, 0);
        this.physicsWorld.setGravity(gravity);

        const worldInfo = this.physicsWorld.getWorldInfo();
        worldInfo.set_m_gravity(gravity);

        this.tempTransform = new ammo.btTransform();
        this.tempVec = new ammo.btVector3();
        this.tempQuat = new ammo.btQuaternion();

        this.isReady = true;
        console.log("[AR Engine] Ammo.js Physics Initialized.");
    }

    /**
     * Creates a Kinematic Capsule (mass 0) used for the Torso and Arms.
     * Kinematic objects push soft bodies but ignore gravity.
     */
    createKinematicCapsule(radius: number, height: number, mesh: THREE.Object3D) {
        if (!this.isReady || !this.physicsWorld) return null;

        const shape = new window.Ammo.btCapsuleShape(radius, height);

        const transform = new window.Ammo.btTransform();
        transform.setIdentity();

        const pos = mesh.getWorldPosition(new THREE.Vector3());
        const quat = mesh.getWorldQuaternion(new THREE.Quaternion());

        const ammoPos = new window.Ammo.btVector3(pos.x, pos.y, pos.z);
        const ammoQuat = new window.Ammo.btQuaternion(quat.x, quat.y, quat.z, quat.w);

        transform.setOrigin(ammoPos);
        transform.setRotation(ammoQuat);

        const motionState = new window.Ammo.btDefaultMotionState(transform);

        const localInertia = new window.Ammo.btVector3(0, 0, 0);
        const rbInfo = new window.Ammo.btRigidBodyConstructionInfo(0, motionState, shape, localInertia);
        const body = new window.Ammo.btRigidBody(rbInfo);

        // Flags: 2 = CF_KINEMATIC_OBJECT
        body.setCollisionFlags(body.getCollisionFlags() | 2);
        // State: 4 = DISABLE_DEACTIVATION (so it updates every frame)
        body.setActivationState(4);

        this.physicsWorld.addRigidBody(body);

        window.Ammo.destroy(ammoPos);
        window.Ammo.destroy(ammoQuat);
        window.Ammo.destroy(localInertia);
        window.Ammo.destroy(transform);

        return body;
    }

    /**
     * Updates a Kinematic body to match its linked Three.js mesh's real-time position.
     */
    updateKinematicBody(body: Ammo.btRigidBody, mesh: THREE.Object3D) {
        if (!this.isReady || !this.tempTransform || !this.tempVec || !this.tempQuat) return;

        const ms = body.getMotionState();
        if (ms) {
            const pos = mesh.getWorldPosition(new THREE.Vector3());
            const quat = mesh.getWorldQuaternion(new THREE.Quaternion());

            this.tempVec.setValue(pos.x, pos.y, pos.z);
            this.tempQuat.setValue(quat.x, quat.y, quat.z, quat.w);

            this.tempTransform.setIdentity();
            this.tempTransform.setOrigin(this.tempVec);
            this.tempTransform.setRotation(this.tempQuat);

            ms.setWorldTransform(this.tempTransform);
        }
    }

    /**
     * Converts a Three.js Mesh into an Ammo.js SoftBody (Cloth).
     * Binds the BufferGeometry vertices into the Wasm memory heap.
     */
    createSoftBodyFromMesh(mesh: THREE.Mesh, mass: number = 10, margin: number = 0.05) {
        if (!this.isReady || !this.physicsWorld) return null;

        const geometry = mesh.geometry as THREE.BufferGeometry;
        const positions = geometry.attributes.position.array as Float32Array;
        const indexAttr = geometry.index;

        if (!indexAttr) {
            console.warn("PhysicsEngine: Cannot create softbody. Geometry lacks indices.");
            return null;
        }

        const indices = indexAttr.array;
        const numTriangles = indices.length / 3;

        // Allocate memory inside Ammo Wasm Heap
        const ammoVertices = window.Ammo._malloc(positions.length * Float32Array.BYTES_PER_ELEMENT);
        const isU32 = indices instanceof Uint32Array;
        const indexBytes = isU32 ? Uint32Array.BYTES_PER_ELEMENT : Uint16Array.BYTES_PER_ELEMENT;
        const ammoIndices = window.Ammo._malloc(indices.length * indexBytes);

        // Copy JavaScript typed arrays into Wasm Heap
        window.Ammo.HEAPF32.set(positions, ammoVertices / Float32Array.BYTES_PER_ELEMENT);
        if (isU32) {
            window.Ammo.HEAPU32.set(indices, ammoIndices / Uint32Array.BYTES_PER_ELEMENT);
        } else {
            window.Ammo.HEAPU16.set(indices as Uint16Array, ammoIndices / Uint16Array.BYTES_PER_ELEMENT);
        }

        // Generate the SoftBody
        const softBodyHelpers = new window.Ammo.btSoftBodyHelpers();
        const body = softBodyHelpers.CreateFromTriMesh(
            this.physicsWorld.getWorldInfo(),
            ammoVertices,
            ammoIndices,
            numTriangles,
            true
        );

        // Configure internal Physics Properties for Cloth
        const sbConfig = body.get_m_cfg();
        sbConfig.set_viterations(10); // Vertex solver iterations
        sbConfig.set_piterations(10); // Position solver iterations

        sbConfig.set_collisions(0x11); // Collide with Rigids and Softs
        sbConfig.set_kDF(1.0); // Dynamic friction
        sbConfig.set_kDP(0.01); // Damping
        sbConfig.set_kPR(2.5); // Pressure

        const material = body.appendMaterial();
        material.set_m_kLST(0.8); // Linear stiffness
        material.set_m_kAST(0.8); // Angular stiffness
        material.set_m_kVST(0.8); // Volume stiffness

        body.generateBendingConstraints(2, material);
        body.setTotalMass(mass, false);

        // [ANCHOR ALGORITHM]: Pin the Collar!
        // We find the highest Y vertices and set their mass to 0 so they never fall.
        let maxY = -Infinity;
        let minY = Infinity;
        for (let i = 1; i < positions.length; i += 3) {
            if (positions[i] > maxY) maxY = positions[i];
            if (positions[i] < minY) minY = positions[i];
        }

        const heightRange = maxY - minY;
        const collarThreshold = maxY - (heightRange * 0.15); // Top 15% of the garment

        const nodes = body.get_m_nodes();
        const numNodes = nodes.size();
        for (let j = 0; j < numNodes; j++) {
            const node = nodes.at(j);
            const nodeY = node.get_m_x().y();
            if (nodeY > collarThreshold) {
                // Set inverse mass to 0 (makes the particle perfectly static)
                // Using set_m_im requires type support. Instead we can append an anchor.
                // Or simply set mass to 0, but total mass handles that. Let's just set individual mass.
                // body.setMass(j, 0); 
                // We'll append an anchor to the world directly (RigidBody not required if static)
                // For now, setting vertex mass to 0 is the Ammo way.
            }
        }
        // Since we need body.setMass(node, 0), let's ensure it's in ammo.d.ts or use it as any.
        for (let j = 0; j < numNodes; j++) {
            const node = nodes.at(j);
            const nodeY = node.get_m_x().y();
            if (nodeY > collarThreshold) {
                (body as any).setMass(j, 0);
            }
        }

        // Sync initial transform to visual mesh
        const transform = new window.Ammo.btTransform();
        transform.setIdentity();

        const pos = mesh.getWorldPosition(new THREE.Vector3());
        const quat = mesh.getWorldQuaternion(new THREE.Quaternion());

        const ammoPos = new window.Ammo.btVector3(pos.x, pos.y, pos.z);
        const ammoQuat = new window.Ammo.btQuaternion(quat.x, quat.y, quat.z, quat.w);
        transform.setOrigin(ammoPos);
        transform.setRotation(ammoQuat);
        // Note: setting world transform on SoftBody involves transforming its nodes, 
        // usually handled by translating the geometry before passing to ammo, 
        // or using body.transform(transform).

        window.Ammo.destroy(ammoPos);
        window.Ammo.destroy(ammoQuat);
        window.Ammo.destroy(transform);

        // Add to simulation
        this.physicsWorld.addSoftBody(body);

        // Push to render sync loop
        this.softBodies.push({ mesh, body });

        // Free Heap allocations after ingestion
        window.Ammo._free(ammoVertices);
        window.Ammo._free(ammoIndices);

        return body;
    }

    step(deltaTime: number) {
        if (!this.isReady || !this.physicsWorld) return;

        // Step physics simulation
        this.physicsWorld.stepSimulation(deltaTime, 10);

        // Sync Rigid Bodies back to Three.js
        for (let i = 0; i < this.rigidBodies.length; i++) {
            const entry = this.rigidBodies[i];
            const ms = entry.body.getMotionState();
            if (ms && this.tempTransform) {
                ms.getWorldTransform(this.tempTransform);
                const p = this.tempTransform.getOrigin();
                const q = this.tempTransform.getRotation();
                entry.mesh.position.set(p.x(), p.y(), p.z());
                entry.mesh.quaternion.set(q.x(), q.y(), q.z(), q.w());
            }
        }

        // Sync Soft Bodies back to Three.js
        for (let i = 0; i < this.softBodies.length; i++) {
            const entry = this.softBodies[i];
            const geometry = (entry.mesh as THREE.Mesh).geometry as THREE.BufferGeometry;
            const positions = geometry.attributes.position.array as Float32Array;

            const nodes = entry.body.get_m_nodes();
            const numNodes = nodes.size();

            // Raw pointer sync for extremely high performance
            for (let j = 0; j < numNodes; j++) {
                const nodePos = nodes.at(j).get_m_x();
                positions[j * 3] = nodePos.x();
                positions[j * 3 + 1] = nodePos.y();
                positions[j * 3 + 2] = nodePos.z();
            }

            geometry.attributes.position.needsUpdate = true;
            geometry.computeVertexNormals();
        }
    }

    getWorld() {
        return this.physicsWorld;
    }
}
