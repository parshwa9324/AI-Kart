# WebGLMeshLayer Implementation

## Overview

`WebGLMeshLayer` is a drop-in replacement for `MeshWarper` that uses WebGL1 for hardware-accelerated triangle rendering while maintaining full compatibility with the `IMeshLayer` interface.

## Architecture

### Key Design Decisions

1. **Separate WebGL Canvas**: WebGL and Canvas2D cannot share the same canvas element, so we use an offscreen WebGL canvas and composite it onto the main canvas via `drawImage()`.

2. **Geometry Reuse**: The class wraps `MeshWarper` to reuse all geometry computation logic (mesh warping, constraints, validation). Only the rendering path differs.

3. **Zero Allocations**: Buffer updates use `bufferSubData()` for position updates and only rebuild indices/texCoords when topology changes.

4. **Automatic Fallback**: Factory function `createMeshLayer()` automatically falls back to `MeshWarper` if WebGL is unavailable or initialization fails.

## Implementation Details

### Shaders

- **Vertex Shader**: Converts pixel coordinates to clip space, flips Y-axis for canvas compatibility
- **Fragment Shader**: Samples texture with brightness/contrast adjustments matching `Renderer.ts` behavior

### Buffer Management

- **Position Buffer**: Updated every frame via `bufferSubData()` (dynamic)
- **TexCoord Buffer**: Updated when source mesh rebuilds (static)
- **Index Buffer**: Rebuilt only when topology changes (static)

### Performance Optimizations

1. **Topology Version Tracking**: Avoids rebuilding indices/texCoords unnecessarily
2. **Conditional Buffer Updates**: Only uploads to GPU when mesh actually changes
3. **Static Shader Compilation**: Shaders compiled once at initialization
4. **No Dynamic Allocations**: Reuses Float32Array/Uint16Array buffers

## Usage

```typescript
import { createMeshLayer } from './WebGLMeshLayer';

// Engine automatically uses WebGL if available, falls back to Canvas2D
const meshLayer = createMeshLayer(canvas, garmentProfile);
```

## Fallback Behavior

The factory function:
1. Checks WebGL availability via `isWebGLSupported()`
2. Attempts WebGL initialization
3. Falls back to `MeshWarper` (Canvas2D) if WebGL fails
4. No changes needed in `Engine.ts` - it works transparently

## Limitations

1. **Occlusion Handling**: Occlusions are still rendered via Canvas2D overlay (more efficient than WebGL render-to-texture for small regions)

2. **Context Loss**: WebGL context loss recovery not implemented (would require reinitialization)

3. **Memory**: Uses additional offscreen canvas (minimal overhead)

## Performance Targets

- ✅ FPS ≥ 24 maintained
- ✅ Zero allocations in render hot path
- ✅ Static shader compilation
- ✅ Efficient buffer updates

## Testing

To test WebGL fallback:
1. Disable WebGL in browser (chrome://flags → Disable WebGL)
2. Verify Canvas2D fallback works correctly
3. Re-enable WebGL and verify WebGL path works
