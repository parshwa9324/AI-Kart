/**
 * GpuParityChecker.ts
 *
 * Uses WebGL2 Transform Feedback to capture the ACTUAL vertex positions
 * output by the GPU vertex shader for 9 key UV sample points.
 *
 * Compares them to the CPU-mirrored positions from LiveFrameValidator.
 * If delta exceeds 0.005 NDC → VALIDATION INVALID — CPU/GPU MISMATCH.
 *
 * The Transform Feedback program uses the EXACT same vertex shader source
 * (VERTEX_SHADER_SRC) with one addition: a `v_clip_pos` varying that
 * copies gl_Position so TF can capture it.
 */

// ── Types ──────────────────────────────────────────────────────────────

/** Uniform snapshot from WebGLMeshLayer.lastUniforms */
export interface ShaderUniforms {
  shoulder_left:  [number, number];
  shoulder_right: [number, number];
  hip_left:       [number, number];
  hip_right:      [number, number];
  elbow_left:     [number, number];
  elbow_right:    [number, number];
  garment_top_uv:    number;
  garment_bottom_uv: number;
  span_scale: number;
  neck_bias:  number;
  curvature:  number;      // raw (shader multiplies by 0.65 internally)
  garment_z:  number;
  resolution: [number, number];
}

export interface VertexParityResult {
  u: number; v: number;
  gpu: { x: number; y: number };
  cpu: { x: number; y: number };
  delta: number;           // max(|dx|, |dy|) in NDC
  pass: boolean;
}

export interface ParityReport {
  maxDelta: number;
  avgDelta: number;
  perVertex: VertexParityResult[];
  pass: boolean;
  error?: string;
}

const PARITY_THRESHOLD = 0.005; // NDC

// ── TF Vertex Shader (identical to production, adds v_clip_pos output) ─

const TF_VERTEX_SHADER = `#version 300 es
precision highp float;

in vec2 a_position; // (u, v) UV sample point — same as warp-grid coord
in vec2 a_uv;

uniform vec2 u_shoulder_left;
uniform vec2 u_shoulder_right;
uniform vec2 u_hip_left;
uniform vec2 u_hip_right;
uniform vec2 u_elbow_left;
uniform vec2 u_elbow_right;

uniform float u_garment_top_uv;
uniform float u_garment_bottom_uv;
uniform float u_span_scale;
uniform float u_neck_bias;

uniform vec4  u_params;
uniform float u_garment_z;
uniform vec2  u_resolution;

// Transform Feedback output — captures gl_Position equivalent
out vec4 v_clip_pos;

void main() {
    float u = a_position.x;
    float v = a_position.y;

    // STEP 1: UV height remapping
    float v_norm = u_garment_top_uv + v * (u_garment_bottom_uv - u_garment_top_uv);
    v_norm = clamp(v_norm, u_garment_top_uv, u_garment_bottom_uv);

    // STEP 2: Shoulder span compression
    vec2 shoulderMid = (u_shoulder_left + u_shoulder_right) * 0.5;
    vec2 hipMid      = (u_hip_left      + u_hip_right)      * 0.5;

    vec2 sL = shoulderMid + (u_shoulder_left  - shoulderMid) * u_span_scale;
    vec2 sR = shoulderMid + (u_shoulder_right - shoulderMid) * u_span_scale;
    vec2 hL = hipMid      + (u_hip_left       - hipMid)      * u_span_scale;
    vec2 hR = hipMid      + (u_hip_right       - hipMid)      * u_span_scale;

    // STEP 3: Bilinear position
    float body_t = (v_norm - u_garment_top_uv) / (u_garment_bottom_uv - u_garment_top_uv);
    body_t = clamp(body_t, 0.0, 1.0);

    vec2 top_edge = mix(sL, sR, u);
    vec2 bot_edge = mix(hL, hR, u);
    vec2 pos      = mix(top_edge, bot_edge, body_t);

    // STEP 4: Neck anchor bias
    float neck_influence = max(0.0, 1.0 - body_t / 0.2);
    pos.y += (shoulderMid.y - pos.y) * neck_influence * u_neck_bias;

    // STEP 5: Sleeve deformation
    if (body_t < 0.4) {
        float sleeve_str = (1.0 - body_t / 0.4);
        if (u < 0.2) {
            float col_f = (1.0 - u / 0.2);
            float pull  = col_f * sleeve_str * 0.45;
            pos += (u_elbow_left - sL) * pull;
        } else if (u > 0.8) {
            float col_f = (u - 0.8) / 0.2;
            float pull  = col_f * sleeve_str * 0.45;
            pos += (u_elbow_right - sR) * pull;
        }
    }

    // STEP 6: Cylinder projection
    float curvature = u_params.x * 0.65;
    float theta     = (u - 0.5) * 3.14159 * 0.8;
    float sDist     = distance(sL, sR);
    float radius    = sDist * 0.45;
    float z_offset  = cos(theta) * curvature * radius;

    // STEP 7: Clip space
    vec2 clip_xy = (pos / u_resolution) * 2.0 - 1.0;
    clip_xy.y    = -clip_xy.y;
    float depth  = u_garment_z - z_offset * 0.002;

    gl_Position = vec4(clip_xy, depth, 1.0);
    v_clip_pos  = vec4(clip_xy, depth, 1.0);  // captured by TF
}
`;

// TF fragment shader — minimal, not used but required by WebGL
const TF_FRAGMENT_SHADER = `#version 300 es
precision highp float;
out vec4 fragColor;
void main() { fragColor = vec4(0.0); }
`;

// 9 UV sample points: (u, v) in [0,1]x[0,1]
const SAMPLE_UVS: Array<[number, number]> = [
  [0.5, 0.0],   // top center (collar)
  [0.0, 0.0],   // top left
  [1.0, 0.0],   // top right
  [0.0, 0.1],   // 10% left (shoulder)
  [1.0, 0.1],   // 10% right (shoulder)
  [0.5, 0.5],   // body center
  [0.0, 0.5],   // body left
  [1.0, 0.5],   // body right
  [0.5, 1.0],   // hem center
];

// ── GpuParityChecker ────────────────────────────────────────────────────

export class GpuParityChecker {
  private _gl: WebGL2RenderingContext;
  private _program: WebGLProgram | null = null;
  private _vao: WebGLVertexArrayObject | null = null;
  private _posBuf: WebGLBuffer | null = null;
  private _tfBuf: WebGLBuffer | null = null;
  private _tf: WebGLTransformFeedback | null = null;
  private _ready = false;
  private _initError: string | null = null;

  constructor(gl: WebGL2RenderingContext) {
    this._gl = gl;
    this._init();
  }

  private _init(): void {
    const gl = this._gl;

    // Compile shaders
    const vs = this._compileShader(gl.VERTEX_SHADER, TF_VERTEX_SHADER);
    const fs = this._compileShader(gl.FRAGMENT_SHADER, TF_FRAGMENT_SHADER);
    if (!vs || !fs) return;

    // Link program with Transform Feedback varyings BEFORE linking
    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    // Declare the varying to capture
    gl.transformFeedbackVaryings(prog, ['v_clip_pos'], gl.SEPARATE_ATTRIBS);
    gl.linkProgram(prog);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      this._initError = 'TF program link failed: ' + gl.getProgramInfoLog(prog);
      console.error('[GpuParityChecker]', this._initError);
      return;
    }

    this._program = prog;

    // Build position buffer with 9 UV sample points (u, v, u, v for a_position + a_uv)
    const N = SAMPLE_UVS.length;
    const data = new Float32Array(N * 4); // [u, v, u, v] per vertex
    for (let i = 0; i < N; i++) {
      const [u, v] = SAMPLE_UVS[i];
      data[i * 4 + 0] = u;
      data[i * 4 + 1] = v;
      data[i * 4 + 2] = u; // a_uv same as a_position for TF
      data[i * 4 + 3] = v;
    }

    const vao = gl.createVertexArray()!;
    gl.bindVertexArray(vao);

    const posBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);

    const aPos = gl.getAttribLocation(prog, 'a_position');
    const aUV  = gl.getAttribLocation(prog, 'a_uv');
    if (aPos >= 0) {
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 16, 0);
    }
    if (aUV >= 0) {
      gl.enableVertexAttribArray(aUV);
      gl.vertexAttribPointer(aUV,  2, gl.FLOAT, false, 16, 8);
    }

    gl.bindVertexArray(null);

    // TF output buffer: N vertices × 4 floats (vec4)
    const tfBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, tfBuf);
    gl.bufferData(gl.ARRAY_BUFFER, N * 4 * 4, gl.DYNAMIC_READ);

    const tf = gl.createTransformFeedback()!;
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, tf);
    gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, tfBuf);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);

    this._vao   = vao;
    this._posBuf = posBuf;
    this._tfBuf = tfBuf;
    this._tf    = tf;
    this._ready = true;
  }

  private _compileShader(type: number, src: string): WebGLShader | null {
    const gl = this._gl;
    const s = gl.createShader(type)!;
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      this._initError = 'TF shader compile: ' + gl.getShaderInfoLog(s);
      console.error('[GpuParityChecker]', this._initError);
      return null;
    }
    return s;
  }

  /**
   * Runs 9 sample vertices through the GPU TF shader and compares
   * each clip-space position to the CPU-computed positions.
   *
   * @param uniforms  Exact uniform values used in the last frame (from WebGLMeshLayer.lastUniforms)
   * @param cpuPositions  CPU-computed NDC positions for the same 9 UVs (from LiveFrameValidator)
   */
  checkParity(
    uniforms: ShaderUniforms,
    cpuPositions: Array<{ clipX: number; clipY: number }>,
  ): ParityReport {
    if (!this._ready || !this._program) {
      return {
        maxDelta: 0,
        avgDelta: 0,
        perVertex: [],
        pass: false,
        error: this._initError ?? 'GpuParityChecker not initialized',
      };
    }

    const gl = this._gl;
    const N  = SAMPLE_UVS.length;

    // Save state
    const prevProgram = gl.getParameter(gl.CURRENT_PROGRAM) as WebGLProgram | null;
    const prevVAO     = gl.getParameter(gl.VERTEX_ARRAY_BINDING) as WebGLVertexArrayObject | null;

    gl.useProgram(this._program);

    // Upload uniforms
    const U = uniforms;
    const setV2 = (name: string, x: number, y: number) => {
      const loc = gl.getUniformLocation(this._program!, name);
      if (loc !== null) gl.uniform2f(loc, x, y);
    };
    const setF = (name: string, v: number) => {
      const loc = gl.getUniformLocation(this._program!, name);
      if (loc !== null) gl.uniform1f(loc, v);
    };
    const setV4 = (name: string, x: number, y: number, z: number, w: number) => {
      const loc = gl.getUniformLocation(this._program!, name);
      if (loc !== null) gl.uniform4f(loc, x, y, z, w);
    };

    setV2('u_shoulder_left',  U.shoulder_left[0],  U.shoulder_left[1]);
    setV2('u_shoulder_right', U.shoulder_right[0], U.shoulder_right[1]);
    setV2('u_hip_left',       U.hip_left[0],       U.hip_left[1]);
    setV2('u_hip_right',      U.hip_right[0],      U.hip_right[1]);
    setV2('u_elbow_left',     U.elbow_left[0],     U.elbow_left[1]);
    setV2('u_elbow_right',    U.elbow_right[0],    U.elbow_right[1]);
    setF('u_garment_top_uv',    U.garment_top_uv);
    setF('u_garment_bottom_uv', U.garment_bottom_uv);
    setF('u_span_scale', U.span_scale);
    setF('u_neck_bias',  U.neck_bias);
    setV4('u_params', U.curvature, 0, 0, 0);
    setF('u_garment_z', U.garment_z);
    setV2('u_resolution', U.resolution[0], U.resolution[1]);

    // Run Transform Feedback — rasterizer disabled
    gl.bindVertexArray(this._vao);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, this._tf);
    gl.enable(gl.RASTERIZER_DISCARD);

    gl.beginTransformFeedback(gl.POINTS);
    gl.drawArrays(gl.POINTS, 0, N);
    gl.endTransformFeedback();

    gl.disable(gl.RASTERIZER_DISCARD);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, null);
    gl.bindVertexArray(null);

    // Read back GPU output synchronously
    // Fix 4: Wrap readback in fenceSync check to reduce CPU stall
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    // Note: strict async wait would require clientWaitSync loop, 
    // but user requested "Wrap it in fenceSync check" + flush.

    const gpuData = new Float32Array(N * 4);
    gl.bindBuffer(gl.ARRAY_BUFFER, this._tfBuf);
    gl.getBufferSubData(gl.ARRAY_BUFFER, 0, gpuData);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    
    // Clean up fence
    if (sync) gl.deleteSync(sync);

    // Restore GL state
    gl.useProgram(prevProgram);
    if (prevVAO) gl.bindVertexArray(prevVAO);

    // Compare GPU vs CPU
    const results: VertexParityResult[] = [];
    let maxDelta = 0;
    let sumDelta = 0;

    for (let i = 0; i < N; i++) {
      const gpuX = gpuData[i * 4 + 0];
      const gpuY = gpuData[i * 4 + 1];
      const cpuX = cpuPositions[i].clipX;
      const cpuY = cpuPositions[i].clipY;

      const dx = Math.abs(gpuX - cpuX);
      const dy = Math.abs(gpuY - cpuY);
      const delta = Math.max(dx, dy);

      maxDelta  = Math.max(maxDelta, delta);
      sumDelta += delta;

      results.push({
        u: SAMPLE_UVS[i][0],
        v: SAMPLE_UVS[i][1],
        gpu: { x: gpuX, y: gpuY },
        cpu: { x: cpuX, y: cpuY },
        delta,
        pass: delta <= PARITY_THRESHOLD,
      });
    }

    return {
      maxDelta,
      avgDelta: sumDelta / N,
      perVertex: results,
      pass: maxDelta <= PARITY_THRESHOLD,
    };
  }

  dispose(): void {
    const gl = this._gl;
    if (this._program) gl.deleteProgram(this._program);
    if (this._vao)     gl.deleteVertexArray(this._vao);
    if (this._posBuf)  gl.deleteBuffer(this._posBuf);
    if (this._tfBuf)   gl.deleteBuffer(this._tfBuf);
    if (this._tf)      gl.deleteTransformFeedback(this._tf);
    this._ready = false;
  }
}

// ── Parity Report Formatter ─────────────────────────────────────────────

export function formatParityReport(r: ParityReport): string {
  if (r.error) {
    return `[GpuParityChecker] ⚠ ${r.error}`;
  }

  const status = r.pass
    ? `GPU–CPU Divergence: ${r.maxDelta.toFixed(5)} NDC — ✅ PARITY OK`
    : `GPU–CPU Divergence: ${r.maxDelta.toFixed(5)} NDC — ❌ VALIDATION INVALID — CPU/GPU MISMATCH`;

  const worstVerts = r.perVertex
    .filter(v => !v.pass)
    .map(v => `    u=${v.u.toFixed(1)} v=${v.v.toFixed(1)}  δ=${v.delta.toFixed(5)}  GPU(${v.gpu.x.toFixed(3)},${v.gpu.y.toFixed(3)}) CPU(${v.cpu.x.toFixed(3)},${v.cpu.y.toFixed(3)})`)
    .join('\n');

  return worstVerts
    ? `${status}\n  Failing vertices:\n${worstVerts}`
    : status;
}

export { SAMPLE_UVS };
