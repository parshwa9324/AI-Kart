/**
 * GarmentAnalyzer.ts — Garment Intelligence Layer
 *
 * Pure canvas pixel analysis (no ML). Runs once per garment load.
 *
 * Step 1: Type detection from aspect ratio + contour width profile
 * Step 2: Anchor auto-calibration from contour peaks & edges
 * Step 3: Sleeve length measurement (shoulder→sleeve bottom)
 * Step 4: Hem curvature detection (bottom contour arc)
 */

import type { GarmentAnchors, GarmentType, GarmentProfile } from './GarmentConfig';
import { getGarmentProfile } from './GarmentConfig';

/** Full analysis result — consumed by GarmentLoader and MeshWarper */
export interface GarmentAnalysis {
  /** Detected garment type */
  type: GarmentType;
  /** Calibrated anchors (normalized 0-1) */
  anchors: GarmentAnchors;
  /** Full profile with calibrated anchors merged */
  profile: GarmentProfile;
  /** Step 3: Sleeve length as fraction of garment height (0-1) */
  sleeveLength: number;
  /** Step 3: Mesh row where sleeve influence should end (normalized 0-1) */
  sleeveEndRow: number;
  /** Step 4: Hem curvature strength (0 = flat, positive = concave up) */
  hemCurvature: number;
  /** Analysis confidence (0-1). <0.5 triggers safe mode. */
  confidence: number;
  /** Raw width profile used for diagnostics */
  widthProfile: Float32Array;
}

// ── Scan resolution (downsampled for speed) ─────────────────

const SCAN_W = 128;
const SCAN_H = 192;

export class GarmentAnalyzer {
  /**
   * Full analysis pipeline. Input: transparent garment canvas.
   * Returns calibrated profile ready for MeshWarper.
   */
  static analyze(canvas: HTMLCanvasElement): GarmentAnalysis {
    // Downsample to fixed size for consistent scanning
    const scan = this.downsample(canvas);
    const alpha = this.extractAlpha(scan);

    // Step 1: Width profile + type detection
    const widthProfile = this.computeWidthProfile(alpha);
    const type = this.detectType(canvas.width, canvas.height, widthProfile);

    // Step 2: Anchor auto-calibration
    const anchors = this.calibrateAnchors(alpha, widthProfile, type);

    // Step 3: Sleeve length
    const sleeveData = this.measureSleeveLength(widthProfile, anchors);

    // Step 4: Hem curvature
    const hemCurvature = this.detectHemCurvature(alpha);

    // Confidence scoring (Phase 7)
    // Reduce confidence if hem scan failed or aspect ratio is extreme
    let confidence = 0.95;
    if (hemCurvature === 0 && alpha.length > 0) confidence -= 0.2; // hem scan failed
    const ar = canvas.height / canvas.width;
    if (ar > 2.2 || ar < 0.8) confidence -= 0.3; // extreme aspect ratio

    // Merge calibrated anchors into profile
    const profile = getGarmentProfile(type, anchors);

    return {
      type,
      anchors,
      profile,
      sleeveLength: sleeveData.length,
      sleeveEndRow: sleeveData.endRow,
      hemCurvature,
      confidence: Math.max(0.1, confidence),
      widthProfile,
    };
  }

  // ── Step 1: Type Detection ──────────────────────────────

  private static detectType(
    origW: number,
    origH: number,
    widthProfile: Float32Array
  ): GarmentType {
    const aspectRatio = origH / origW;

    // Find where the garment is widest (sleeve region)
    let maxWidth = 0;
    let maxWidthRow = 0;
    for (let i = 0; i < widthProfile.length; i++) {
      if (widthProfile[i] > maxWidth) {
        maxWidth = widthProfile[i];
        maxWidthRow = i;
      }
    }
    const maxWidthNorm = maxWidthRow / widthProfile.length; // 0-1

    // Sleeve width ratio: how wide are sleeves vs body
    const bodyWidth = this.medianWidth(widthProfile, 0.5, 0.7); // mid-body
    const sleeveWidth = this.medianWidth(widthProfile, 0.15, 0.35); // upper region
    const sleeveWidthRatio = bodyWidth > 0 ? sleeveWidth / bodyWidth : 1;

    // Width drop-off: where sleeve ends
    // For long sleeves, the wide region extends lower
    const wideRegionEnd = this.findWidthDropoff(widthProfile, maxWidth * 0.7);
    const wideRegionNorm = wideRegionEnd / widthProfile.length;

    // Decision tree (Phase 7 updated)
    if (aspectRatio > 1.5 && wideRegionNorm > 0.5) return 'longsleeve';
    if (aspectRatio > 1.35 && sleeveWidthRatio > 1.15) return 'hoodie';
    
    // Oversized check: wide structure + deep sleeves or boxy aspect ratio
    if (wideRegionNorm > 0.6 && sleeveWidthRatio < 1.3) return 'oversized';
    if (aspectRatio < 0.95 && wideRegionNorm > 0.45) return 'oversized';

    if (aspectRatio > 1.2 && wideRegionNorm > 0.35) return 'shirt';
    if (aspectRatio > 1.1 && wideRegionNorm > 0.3) return 'shirt';
    return 'tshirt';
  }

  // ── Step 2: Anchor Auto-Calibration ─────────────────────

  private static calibrateAnchors(
    alpha: Uint8Array,
    widthProfile: Float32Array,
    type: GarmentType
  ): GarmentAnchors {
    // Find top contour (neckline + shoulder peaks)
    const topContour = this.scanTopContour(alpha);
    // Find left/right contour at each row
    const leftEdge = new Float32Array(SCAN_H);
    const rightEdge = new Float32Array(SCAN_H);
    this.scanHorizontalEdges(alpha, leftEdge, rightEdge);

    // ── Neck center: topmost row with >5% coverage
    let neckRow = 0;
    for (let y = 0; y < SCAN_H; y++) {
      if (widthProfile[y] > 0.05) { neckRow = y; break; }
    }
    const neckX = (leftEdge[neckRow] + rightEdge[neckRow]) * 0.5 / SCAN_W;
    const neckY = neckRow / SCAN_H;

    // ── Shoulder peaks: widest points in top 25% of garment
    const shoulderRegionEnd = Math.floor(SCAN_H * 0.25);
    let maxW = 0;
    let shoulderRow = neckRow + 2;
    for (let y = neckRow; y < shoulderRegionEnd; y++) {
      if (widthProfile[y] > maxW) {
        maxW = widthProfile[y];
        shoulderRow = y;
      }
    }
    const shoulderY = shoulderRow / SCAN_H;
    const shoulderLeftX = leftEdge[shoulderRow] / SCAN_W;
    const shoulderRightX = rightEdge[shoulderRow] / SCAN_W;

    // Inset shoulders slightly from outer edge (seam sits ~15% inward)
    const shoulderInset = (shoulderRightX - shoulderLeftX) * 0.12;

    // ── Sleeve endpoints: find widest horizontal extent
    let sleeveRow = shoulderRow;
    let sleeveMaxW = 0;
    const sleeveSearchEnd = Math.floor(SCAN_H * 0.6);
    for (let y = shoulderRow; y < sleeveSearchEnd; y++) {
      const w = rightEdge[y] - leftEdge[y];
      if (w > sleeveMaxW) {
        sleeveMaxW = w;
        sleeveRow = y;
      }
    }
    const sleeveY = sleeveRow / SCAN_H;
    const sleeveLeftX = leftEdge[sleeveRow] / SCAN_W;
    const sleeveRightX = rightEdge[sleeveRow] / SCAN_W;

    // ── Hem: bottom contour
    let hemRow = SCAN_H - 1;
    for (let y = SCAN_H - 1; y > SCAN_H * 0.5; y--) {
      if (widthProfile[y] > 0.05) { hemRow = y; break; }
    }
    const hemY = hemRow / SCAN_H;
    const hemLeftX = leftEdge[hemRow] / SCAN_W;
    const hemRightX = rightEdge[hemRow] / SCAN_W;

    return {
      neckCenter: { x: neckX, y: neckY },
      leftShoulder: { x: shoulderLeftX + shoulderInset, y: shoulderY },
      rightShoulder: { x: shoulderRightX - shoulderInset, y: shoulderY },
      leftSleeve: { x: sleeveLeftX, y: sleeveY },
      rightSleeve: { x: sleeveRightX, y: sleeveY },
      hemLeft: { x: hemLeftX, y: hemY },
      hemRight: { x: hemRightX, y: hemY },
    };
  }

  // ── Step 3: Sleeve Length ───────────────────────────────

  private static measureSleeveLength(
    widthProfile: Float32Array,
    anchors: GarmentAnchors
  ): { length: number; endRow: number } {
    // Sleeve length = distance from shoulder Y to sleeve Y
    const sleeveVertical = Math.abs(anchors.leftSleeve.y - anchors.leftShoulder.y);

    // Map to mesh row: sleeve influence should end at this normalized position
    // Short sleeve (~0.15-0.25 of garment) → endRow ~0.35
    // Long sleeve (~0.4-0.55 of garment) → endRow ~0.6
    const endRow = Math.min(0.7, anchors.leftSleeve.y + 0.05);

    return { length: sleeveVertical, endRow };
  }

  // ── Step 4: Hem Curvature ────────────────────────────────

  private static detectHemCurvature(alpha: Uint8Array): number {
    // Scan bottom contour: for each column, find lowest opaque pixel
    const bottomY = new Float32Array(SCAN_W);
    let minY = SCAN_H;
    let maxY = 0;
    let validCols = 0;

    for (let x = 0; x < SCAN_W; x++) {
      let found = false;
      for (let y = SCAN_H - 1; y >= SCAN_H * 0.5; y--) {
        if (alpha[y * SCAN_W + x] > 128) {
          bottomY[x] = y;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
          validCols++;
          found = true;
          break;
        }
      }
      if (!found) bottomY[x] = -1;
    }

    if (validCols < SCAN_W * 0.3) return 0; // not enough data

    // Find first and last valid columns
    let firstCol = 0, lastCol = SCAN_W - 1;
    while (firstCol < SCAN_W && bottomY[firstCol] < 0) firstCol++;
    while (lastCol > 0 && bottomY[lastCol] < 0) lastCol--;
    if (lastCol - firstCol < 10) return 0;

    // Curvature: compare center Y to edge Y
    const centerCol = Math.floor((firstCol + lastCol) / 2);
    const centerY = bottomY[centerCol];

    // Average edge Y (left and right 15%)
    const edgeRange = Math.max(3, Math.floor((lastCol - firstCol) * 0.15));
    let leftEdgeY = 0, rightEdgeY = 0, leftCount = 0, rightCount = 0;
    for (let i = firstCol; i < firstCol + edgeRange; i++) {
      if (bottomY[i] >= 0) { leftEdgeY += bottomY[i]; leftCount++; }
    }
    for (let i = lastCol - edgeRange; i <= lastCol; i++) {
      if (bottomY[i] >= 0) { rightEdgeY += bottomY[i]; rightCount++; }
    }

    if (leftCount === 0 || rightCount === 0) return 0;
    leftEdgeY /= leftCount;
    rightEdgeY /= rightCount;

    const avgEdgeY = (leftEdgeY + rightEdgeY) / 2;
    // Positive curvature = center is higher than edges (concave up / curved hem)
    const curvaturePx = avgEdgeY - centerY;
    // Normalize to garment height fraction
    return curvaturePx / SCAN_H;
  }

  // ── Helper: Image Processing ─────────────────────────────

  private static downsample(canvas: HTMLCanvasElement): HTMLCanvasElement {
    const out = document.createElement('canvas');
    out.width = SCAN_W;
    out.height = SCAN_H;
    const ctx = out.getContext('2d', { willReadFrequently: true })!;
    ctx.drawImage(canvas, 0, 0, SCAN_W, SCAN_H);
    return out;
  }

  private static extractAlpha(canvas: HTMLCanvasElement): Uint8Array {
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
    const data = ctx.getImageData(0, 0, SCAN_W, SCAN_H).data;
    const alpha = new Uint8Array(SCAN_W * SCAN_H);
    for (let i = 0; i < alpha.length; i++) {
      alpha[i] = data[i * 4 + 3];
    }
    return alpha;
  }

  /** Per-row: fraction of opaque pixels (0-1) */
  private static computeWidthProfile(alpha: Uint8Array): Float32Array {
    const profile = new Float32Array(SCAN_H);
    for (let y = 0; y < SCAN_H; y++) {
      let count = 0;
      const rowStart = y * SCAN_W;
      for (let x = 0; x < SCAN_W; x++) {
        if (alpha[rowStart + x] > 128) count++;
      }
      profile[y] = count / SCAN_W;
    }
    return profile;
  }

  /** Scan leftmost and rightmost opaque pixel per row */
  private static scanHorizontalEdges(
    alpha: Uint8Array,
    leftEdge: Float32Array,
    rightEdge: Float32Array
  ): void {
    for (let y = 0; y < SCAN_H; y++) {
      const rowStart = y * SCAN_W;
      leftEdge[y] = SCAN_W; // default: no pixel
      rightEdge[y] = 0;

      for (let x = 0; x < SCAN_W; x++) {
        if (alpha[rowStart + x] > 128) {
          if (x < leftEdge[y]) leftEdge[y] = x;
          if (x > rightEdge[y]) rightEdge[y] = x;
        }
      }
    }
  }

  /** Top contour: for each column, find topmost opaque pixel */
  private static scanTopContour(alpha: Uint8Array): Float32Array {
    const topY = new Float32Array(SCAN_W);
    for (let x = 0; x < SCAN_W; x++) {
      topY[x] = SCAN_H; // default: not found
      for (let y = 0; y < SCAN_H; y++) {
        if (alpha[y * SCAN_W + x] > 128) {
          topY[x] = y;
          break;
        }
      }
    }
    return topY;
  }

  /** Median width in a row range */
  private static medianWidth(
    profile: Float32Array,
    startFrac: number,
    endFrac: number
  ): number {
    const s = Math.floor(startFrac * profile.length);
    const e = Math.floor(endFrac * profile.length);
    const values: number[] = [];
    for (let i = s; i < e; i++) values.push(profile[i]);
    values.sort((a, b) => a - b);
    return values.length > 0 ? values[Math.floor(values.length / 2)] : 0;
  }

  /** Find row where width drops below threshold (sleeve ending) */
  private static findWidthDropoff(profile: Float32Array, threshold: number): number {
    let maxRow = 0;
    let inWide = false;
    for (let i = 0; i < profile.length; i++) {
      if (profile[i] >= threshold) {
        inWide = true;
        maxRow = i;
      } else if (inWide) {
        return maxRow;
      }
    }
    return maxRow;
  }
}
