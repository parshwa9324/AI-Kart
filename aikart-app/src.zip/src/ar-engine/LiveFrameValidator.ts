/**
 * LiveFrameValidator.ts  — Phase 2: Real-frame validation
 *
 * Validates the ACTUAL shader output every 120 frames using:
 *   1. CPU mirror of vertex shader (all 7 steps) using EXACT GPU uniform values
 *   2. GpuParityChecker Transform Feedback to confirm CPU ≈ GPU
 *   3. gl.readPixels() alpha leakage detection
 *
 * IMPORTANT: CPU mirror now receives the same coordinates the shader receives
 * (u_shoulder_left = computed garment corner tlx/tly, NOT raw landmark).
 * This eliminates the coordinate-system mismatch from Phase 2 v1.
 */

import type { GarmentFit } from './GarmentFitValidator';
import type { PoseMeshInput } from './interfaces/IMeshLayer';
import {
  GpuParityChecker,
  formatParityReport,
  SAMPLE_UVS,
  type ShaderUniforms,
  type ParityReport,
} from './GpuParityChecker';

// ── Thresholds ──────────────────────────────────────────────────────────

const COLLAR_DRIFT_T    = 0.04;  // 4% of torso height
const SHOULDER_W_T      = 0.06;  // 6% width mismatch
const DEPTH_VARIANCE_T  = 0.02;  // z std-dev in clip space
const EXPLOSION_BOUND   = 1.2;   // absolute clip coord
const ALPHA_LEAK_T      = 0.15;  // 15% transparent pixels in garment bbox

// ── Types ───────────────────────────────────────────────────────────────

export interface ScreenVertex {
  x: number;      // screen pixels
  y: number;
  z: number;      // depth (clip space)
  clipX: number;
  clipY: number;
}

export interface LiveValidationReport {
  frameIndex: number;
  // Metric values
  collarDrift: number;
  shoulderWidthError: number;
  depthVariance: number;
  maxClipCoord: number;
  alphaLeakage: number;
  // Adaptive Params
  adaptiveSpan: number;
  adaptiveNeck: number;
  // Parity
  parity: ParityReport | null;
  // Pass/Fail
  collarPass:        boolean;
  shoulderWidthPass: boolean;
  depthPass:         boolean;
  explosionPass:     boolean;
  alphaPass:         boolean;
  parityPass:        boolean;
  overallPass:       boolean;
  failReasons:       string[];
  timestamp: number;
}

// ── CPU Vertex Shader Mirror ────────────────────────────────────────────
//
// Mirrors all 7 vertex shader steps using EXACT uniform values.
// `uniforms` comes from WebGLMeshLayer.lastUniforms — the same Float32 values
// that were uploaded to the GPU. This eliminates coordinate-system drift.

export function computeVertexCPU(
  uv: { x: number; y: number },
  U: ShaderUniforms,
  resW: number,
  resH: number
): { x: number; y: number; z: number; clipX: number; clipY: number } {
  const u = uv.x;
  const v = uv.y; // Standard UV (Revert flip: SAMPLE_UVS 0=Top matches Grid 0=Top)

  const topUV = U.garment_top_uv;
  const botUV = U.garment_bottom_uv;
  const span  = U.span_scale;
  const neckBias = U.neck_bias;
  const curvRaw  = U.curvature;

  const slx = U.shoulder_left[0],  sly = U.shoulder_left[1];
  const srx = U.shoulder_right[0], sry = U.shoulder_right[1];
  const hlx = U.hip_left[0],       hly = U.hip_left[1];
  const hrx = U.hip_right[0],      hry = U.hip_right[1];
  const elx = U.elbow_left[0],     ely = U.elbow_left[1];
  const erx = U.elbow_right[0],    ery = U.elbow_right[1];

  // Debug for center pixel
  const isCenter = Math.abs(u - 0.5) < 0.01 && Math.abs(uv.y - 0.5) < 0.01;

  // STEP 1: UV height remapping
  // v goes 0..1 inside the grid.
  const v_normRaw = topUV + v * (botUV - topUV);
  const v_norm = Math.max(topUV, Math.min(botUV, v_normRaw));
  
  if (isCenter) console.log(`[CPU Step1] v=${v.toFixed(3)} v_norm=${v_norm.toFixed(3)} (top=${topUV.toFixed(3)})`);

  // STEP 2: Span compression
  const sMx = (slx + srx) * 0.5, sMy = (sly + sry) * 0.5;
  const hMx = (hlx + hrx) * 0.5, hMy = (hly + hry) * 0.5;

  const sLx = sMx + (slx - sMx) * span,  sLy = sMy + (sly - sMy) * span;
  const sRx = sMx + (srx - sMx) * span,  sRy = sMy + (sry - sMy) * span;
  const hLx = hMx + (hlx - hMx) * span,  hLy = hMy + (hly - hMy) * span;
  const hRx = hMx + (hrx - hMx) * span,  hRy = hMy + (hry - hMy) * span;

  if (isCenter) console.log(`[CPU Step2] sLx=${sLx.toFixed(1)} sRx=${sRx.toFixed(1)} span=${span.toFixed(2)}`);

  // STEP 3: Bilinear
  const body_t = Math.max(0, Math.min(1, (v_norm - topUV) / (botUV - topUV)));
  const teX = sLx + (sRx - sLx) * u,   teY = sLy + (sRy - sLy) * u;
  const beX = hLx + (hRx - hLx) * u,   beY = hLy + (hRy - hLy) * u;
  let posX = teX + (beX - teX) * body_t;
  let posY = teY + (beY - teY) * body_t;

  if (isCenter) console.log(`[CPU Step3] pos=(${posX.toFixed(1)}, ${posY.toFixed(1)}) body_t=${body_t.toFixed(3)}`);

  // STEP 4: Neck anchor bias (GLSL Match: line 93-102)
  const neck_inf = Math.max(0, 1.0 - body_t / 0.2);
  // GLSL computes sDist here but uses it later.
  // GLSL: pos.y += (shoulderMid.y - pos.y) * neck_influence * u_neck_bias;
  // shoulderMid.y is sMy
  posY += (sMy - posY) * neck_inf * neckBias;

  // STEP 5: Sleeve deformation (GLSL Match: line 106-121)
  if (body_t < 0.4) {
    const sleeve_str = 1.0 - body_t / 0.4;
    // u < 0.2
    if (u < 0.2) {
      const col_f = 1.0 - u / 0.2;
      const pull  = col_f * sleeve_str * 0.45;
      posX += (elx - sLx) * pull;
      posY += (ely - sLy) * pull;
    } 
    // u > 0.8
    else if (u > 0.8) {
      const col_f = (u - 0.8) / 0.2;
      const pull  = col_f * sleeve_str * 0.45;
      posX += (erx - sRx) * pull;
      posY += (ery - sRy) * pull;
    }
  }

  // STEP 6: Cylinder projection (GLSL Match: line 123-130)
  const theta    = (u - 0.5) * Math.PI * 0.8;
  // GLSL: sDist = distance(sL, sR) calculated at Step 4/6 boundary
  const sDist    = Math.hypot(sRx - sLx, sRy - sLy);
  const radius   = sDist * 0.45;
  const curvature = curvRaw * 0.65;
  const z_offset = Math.cos(theta) * curvature * radius;
  const z = U.garment_z - z_offset * 0.002;

  // STEP 7: Clip space
  let clipX =  (posX / resW) * 2.0 - 1.0;
  let clipY = -((posY / resH) * 2.0 - 1.0); // WebGL Y flip

  if (isCenter) console.log(`[CPU Step7] clip=(${clipX.toFixed(3)}, ${clipY.toFixed(3)})`);

  // Hard clamp to prevent explosion (Phase 4 Fix)
  clipX = Math.max(-1.1, Math.min(1.1, clipX));
  clipY = Math.max(-1.1, Math.min(1.1, clipY));

  // Back to screen
  const screenX = (clipX + 1.0) * 0.5 * resW;
  const screenY = (1.0 - (clipY + 1.0) * 0.5) * resH;

  return { x: screenX, y: screenY, z, clipX, clipY };
}

// ── Alpha Leakage ───────────────────────────────────────────────────────

function measureAlphaLeakage(
  ctx: CanvasRenderingContext2D,
  bbox: { minX: number; minY: number; maxX: number; maxY: number },
  canvasW: number,
  canvasH: number,
): number {
  const x = Math.max(0, Math.floor(bbox.minX));
  const y = Math.max(0, Math.floor(canvasH - bbox.maxY)); // WebGL Y is bottom-up
  const w = Math.min(canvasW - x, Math.ceil(bbox.maxX - bbox.minX));
  const h = Math.min(canvasH - y, Math.ceil(bbox.maxY - bbox.minY));
  if (w <= 0 || h <= 0) return 0;

  const sW = Math.min(w, 64);
  const sH = Math.min(h, 64);
  try {
    // 2D Canvas: Image data is strictly (0,0) at top-left
    // We sample the MAIN canvas which has the composited garment
    const data = ctx.getImageData(x, y, sW, sH).data;
    let transparent = 0;
    for (let i = 3; i < data.length; i += 4) {
      if (data[i] < 30) transparent++; // < 12% alpha
    }
    return transparent / (sW * sH);
  } catch {
    return 0; // tainted canvas
  }
}

// ── LiveFrameValidator ──────────────────────────────────────────────────

export class LiveFrameValidator {
  private _frameCount     = 0;
  private _lastReport: LiveValidationReport | null = null;
  private _parityChecker: GpuParityChecker | null  = null;

  get lastReport(): LiveValidationReport | null { return this._lastReport; }

  tick(): boolean {
    this._frameCount++;
    // Fix 4: Reduce validation frequency to 300 frames (user request)
    return this._frameCount % 300 === 0;
  }

  resetFrameCount(): void { this._frameCount = 0; }

  /**
   * Main validation call — runs every 120 frames.
   *
   * @param pose        Raw MediaPipe landmarks (for body-reference metrics)
   * @param fit         Garment corners computed in buildTargetMesh
   * @param uniforms    Exact GPU uniform snapshot (from WebGLMeshLayer.lastUniforms)
   * @param gl          WebGL2 context for readPixels + Transform Feedback
   * @param canvasW/H   Render canvas dimensions
   * @param frameIndex  Running frame count for report labelling
   */
  validate(
    pose: PoseMeshInput,
    fit: GarmentFit,
    uniforms: ShaderUniforms,
    gl: WebGL2RenderingContext | null,
    ctx: CanvasRenderingContext2D | null,
    canvasW: number,
    canvasH: number,
    frameIndex: number,
  ): LiveValidationReport {
    const failReasons: string[] = [];

    // ── Step 1: CPU mirror vertices using actual shader uniforms ──────
    // ── Step 1: CPU mirror vertices using actual shader uniforms ──────
    const cpuVerts = SAMPLE_UVS.map(([u, v]) => computeVertexCPU({ x: u, y: v }, uniforms, canvasW, canvasH));

    // ── Step 2: GPU Parity Check via Transform Feedback ───────────────
    let parity: ParityReport | null = null;
    let parityPass = true;

    if (gl) {
      // Lazy-init parity checker (only once per GL context)
      if (!this._parityChecker) {
        this._parityChecker = new GpuParityChecker(gl);
      }
      parity = this._parityChecker.checkParity(
        uniforms,
        cpuVerts.map(v => ({ clipX: v.clipX, clipY: v.clipY })),
      );
      parityPass = parity.pass;
      if (!parityPass) {
        failReasons.push(
          `VALIDATION INVALID — CPU/GPU MISMATCH  GPU–CPU Divergence: ${parity.maxDelta.toFixed(5)} NDC`
        );
      }
    }

    // ── Only run geometry metrics if parity passes ────────────────────
    // (If GPU ≠ CPU mirror, geometry metrics are meaningless)

    const ls = pose.leftShoulder;
    const rs = pose.rightShoulder;
    const lh = pose.leftHip;
    const rh = pose.rightHip;
    const shoulderMidY  = (ls.y + rs.y) * 0.5;
    const hipMidY       = (lh.y + rh.y) * 0.5;
    const torsoH        = Math.abs(hipMidY - shoulderMidY) || 1;
    const shoulderSpanW = Math.hypot(rs.x - ls.x, rs.y - ls.y);

    // ── METRIC 1: Real Collar Drift ────────────────────────────────────
    // Topmost CPU vertex (v=0 row) vs pose shoulder midpoint Y
    const topmostY = Math.min(...cpuVerts.map(v => v.y));
    const collarDrift = Math.abs(topmostY - shoulderMidY) / torsoH;
    if (parityPass && collarDrift > COLLAR_DRIFT_T) {
      failReasons.push(
        `Collar Drift ${(collarDrift * 100).toFixed(1)}% (>${COLLAR_DRIFT_T * 100}%)`
      );
    }

    // ── METRIC 2: Real Shoulder Width Match ────────────────────────────
    // Garment width at v=0.1 (UV idx 3 & 4 are [0,0.1] and [1,0.1])
    const midTopL = cpuVerts[3]; // [0.0, 0.1]
    const midTopR = cpuVerts[4]; // [1.0, 0.1]
    const garmentWidthAt10 = Math.hypot(midTopR.x - midTopL.x, midTopR.y - midTopL.y);
    const expectedWidth = shoulderSpanW * 1.6 * uniforms.span_scale;
    const shoulderWidthError = Math.abs(garmentWidthAt10 - expectedWidth) / (expectedWidth || 1);
    if (parityPass && shoulderWidthError > SHOULDER_W_T) {
      failReasons.push(
        `Shoulder Width ${(shoulderWidthError * 100).toFixed(1)}% (>${SHOULDER_W_T * 100}%)`
      );
    }
    // Debug: Log excessive width scale
    if (uniforms.span_scale < 0.7) {
      // console.warn(`[LiveVal] Low Span Scale: ${uniforms.span_scale.toFixed(2)}`);
    }

    // ── METRIC 3: Real Depth Consistency ──────────────────────────────
    // Center column z variance: indices 0 (top), 5 (mid), 8 (bot)
    const centerZs = [cpuVerts[0].z, cpuVerts[5].z, cpuVerts[8].z];
    const zMean = centerZs.reduce((a, b) => a + b) / centerZs.length;
    const depthVariance = Math.sqrt(
      centerZs.reduce((s, z) => s + (z - zMean) ** 2, 0) / centerZs.length
    );
    if (parityPass && depthVariance > DEPTH_VARIANCE_T) {
      failReasons.push(`Depth Variance ${depthVariance.toFixed(4)} (>${DEPTH_VARIANCE_T})`);
    }

    // ── METRIC 4: Vertex Explosion ────────────────────────────────────
    const maxClipCoord = Math.max(
      ...cpuVerts.flatMap(v => [Math.abs(v.clipX), Math.abs(v.clipY)])
    );
    if (maxClipCoord > EXPLOSION_BOUND) {
      // Explosion check runs regardless of parity (critical safety gate)
      failReasons.push(`Vertex Explosion: clip=${maxClipCoord.toFixed(2)} (>${EXPLOSION_BOUND})`);
    }

    // ── METRIC 5: Alpha Leakage ────────────────────────────────────────
    let alphaLeakage = 0;
    if (ctx) {
      const bboxMinX = Math.min(...cpuVerts.map(v => v.x));
      const bboxMaxX = Math.max(...cpuVerts.map(v => v.x));
      const bboxMinY = Math.min(...cpuVerts.map(v => v.y));
      const bboxMaxY = Math.max(...cpuVerts.map(v => v.y));
      alphaLeakage = measureAlphaLeakage(
        ctx, { minX: bboxMinX, minY: bboxMinY, maxX: bboxMaxX, maxY: bboxMaxY },
        canvasW, canvasH,
      );
      if (alphaLeakage > ALPHA_LEAK_T) {
        failReasons.push(
          `Alpha Leakage ${(alphaLeakage * 100).toFixed(1)}% (>${ALPHA_LEAK_T * 100}%)`
        );
        // Debug
        // console.log(`[LiveVal] Alpha Fail: ${alphaLeakage.toFixed(2)} bbox=[${bboxMinX.toFixed(0)},${bboxMinY.toFixed(0)},${bboxMaxX.toFixed(0)},${bboxMaxY.toFixed(0)}]`);
      }
    }

    const report: LiveValidationReport = {
      frameIndex,
      collarDrift,
      shoulderWidthError,
      depthVariance,
      maxClipCoord,
      alphaLeakage,
      adaptiveSpan: uniforms.span_scale,
      adaptiveNeck: uniforms.neck_bias,
      parity,
      collarPass:        collarDrift       <= COLLAR_DRIFT_T,
      shoulderWidthPass: shoulderWidthError <= SHOULDER_W_T,
      depthPass:         depthVariance      <= DEPTH_VARIANCE_T,
      explosionPass:     maxClipCoord       <= EXPLOSION_BOUND,
      alphaPass:         alphaLeakage       <= ALPHA_LEAK_T,
      parityPass,
      overallPass:       failReasons.length === 0,
      failReasons,
      timestamp: Date.now(),
    };

    this._lastReport = report;
    return report;
  }

  dispose(): void {
    this._parityChecker?.dispose();
    this._parityChecker = null;
  }
}

// ── Report Formatter ────────────────────────────────────────────────────

const pct = (v: number) => `${(v * 100).toFixed(1)}%`;

export function formatLiveReport(r: LiveValidationReport, garmentName: string): string {
  const ic = (pass: boolean) => pass ? '✅' : '❌';
  const line = (label: string, val: string, pass: boolean) =>
    `  ${label.padEnd(26)} ${val.padStart(9)}  ${ic(pass)}`;

  const parityLine = r.parity
    ? (r.parityPass
        ? `  GPU–CPU Divergence         ${r.parity.maxDelta.toFixed(5).padStart(9)}  ✅`
        : `  GPU–CPU Divergence         ${r.parity.maxDelta.toFixed(5).padStart(9)}  ❌  VALIDATION INVALID`)
    : `  GPU Parity                   N/A       ⚠`;

  return [
    `\n╔═════════════════════════════════════════╗`,
    `║  LIVE VALIDATION — Frame #${String(r.frameIndex).padEnd(14)}║`,
    `║  Garment: ${garmentName.padEnd(30)}║`,
    `║  Span: ${r.adaptiveSpan.toFixed(2)}  Neck: ${r.adaptiveNeck.toFixed(2)}             ║`,
    `╠═════════════════════════════════════════╣`,
    parityLine,
    `  ─────────────────────────────────────`,
    line('Collar Drift',         pct(r.collarDrift),          r.collarPass),
    line('Shoulder Width Error', pct(r.shoulderWidthError),   r.shoulderWidthPass),
    line('Depth Variance',       r.depthVariance.toFixed(4),  r.depthPass),
    line('Max Clip Coord',       r.maxClipCoord.toFixed(3),   r.explosionPass),
    line('Alpha Leakage',        pct(r.alphaLeakage),         r.alphaPass),
    `╠═════════════════════════════════════════╣`,
    `║  STATUS: ${r.overallPass ? 'PASS ✅' : 'FAIL ❌'}                              ║`,
    ...(r.failReasons.map(f => `║  ⚠ ${f.slice(0, 37).padEnd(37)}║`)),
    `╚═════════════════════════════════════════╝`,
  ].join('\n');
}

export { formatParityReport };
