/**
 * WebGLMeshLayer.ts — The Engine Heart (Phase 1 + Fit Stabilization)
 *
 * Fit Stabilization Changes (geometry-only):
 *   1. UV Height Normalization   — u_garment_top_uv / u_garment_bottom_uv
 *   2. Shoulder Span Compression — u_span_scale
 *   3. Curvature reduced to 0.65 multiplier
 *   4. Neck Anchor bias          — u_neck_bias
 */

import type { GarmentProfile } from './GarmentConfig';
import { IRenderer } from './interfaces/IRenderer';
import { IMeshLayer, PoseMeshInput } from './interfaces/IMeshLayer';
import { MeshWarper } from './MeshWarper'; // 2D Fallback
import type { GarmentFit } from './GarmentFitValidator';
import type { ShaderUniforms } from './GpuParityChecker';

// ── Vertex Shader ──────────────────────────────────────────────────────

const VERTEX_SHADER_SRC = `#version 300 es
precision highp float;

// ── Attributes ──
in vec2 a_position; // Warp-grid coord (0..1, 0..1)
in vec2 a_uv;       // Texture coord   (0..1, 0..1)

// ── Body Landmarks (Canvas pixels) ──
uniform vec2 u_shoulder_left;
uniform vec2 u_shoulder_right;
uniform vec2 u_hip_left;
uniform vec2 u_hip_right;
uniform vec2 u_elbow_left;
uniform vec2 u_elbow_right;

// ── Fit Stabilization Uniforms ──
// UV Height Normalization: garment neckline/hem positions in UV space
uniform float u_garment_top_uv;    // default 0.12 — neckline UV
uniform float u_garment_bottom_uv; // default 0.92 — hem UV
// Shoulder Span Compression: scale left/right inward from center
uniform float u_span_scale;        // default 0.90
// Neck Anchor Bias: extra upward push at top of garment
uniform float u_neck_bias;         // default 0.15 (fraction of shoulder-width)

// ── Render Params ──
// u_params: [curvature, reserved, reserved, reserved]
uniform vec4 u_params;
uniform float u_garment_z; // Garment plane depth (0..1)
uniform vec2  u_resolution; // Logical canvas resolution (px)

// ── Outputs ──
out vec2 v_uv;
out vec3 v_normal;

// ─────────────────────────────────────────────────────────────────────
void main() {

    // ── STEP 1: UV HEIGHT REMAPPING ──────────────────────────────────
    // The raw grid v goes 0..1 across the entire vertex rows.
    // But canonical garments have: neckline at UV=0.12, hem at UV=0.92.
    // We remap the grid's v into the range [top_uv .. bottom_uv]
    // so the geometry match the garment's actual content region.
    float v_norm = u_garment_top_uv + a_position.y * (u_garment_bottom_uv - u_garment_top_uv);
    // Clamp to UV content region
    v_norm = clamp(v_norm, u_garment_top_uv, u_garment_bottom_uv);

    // Use re-mapped v for ALL subsequent interpolation
    float u = a_position.x;
    float v = v_norm; // This is now the "body fraction" (0=shoulders, 1=hips)

    // ── STEP 2: SHOULDER SPAN COMPRESSION ────────────────────────────
    // Compress left/right shoulders toward their midpoint by u_span_scale.
    // This prevents over-stretching when MediaPipe gives wide shoulder estimates.
    vec2 shoulderMid = (u_shoulder_left + u_shoulder_right) * 0.5;
    vec2 hipMid      = (u_hip_left      + u_hip_right)      * 0.5;

    vec2 sL = shoulderMid + (u_shoulder_left  - shoulderMid) * u_span_scale;
    vec2 sR = shoulderMid + (u_shoulder_right - shoulderMid) * u_span_scale;
    vec2 hL = hipMid      + (u_hip_left       - hipMid)      * u_span_scale;
    vec2 hR = hipMid      + (u_hip_right      - hipMid)      * u_span_scale;

    // ── STEP 3: BASE BILINEAR POSITION ───────────────────────────────
    // Interpolate garment corners using compressed spans.
    // v_norm = 0 → shoulder row; v_norm = 1 → hip row (within 0.12..0.92 range)
    // But we need v_norm 0..1 for interpolation.
    // Convert v_norm (in top_uv..bottom_uv) to fraction:
    float body_t = (v_norm - u_garment_top_uv) / (u_garment_bottom_uv - u_garment_top_uv);
    body_t = clamp(body_t, 0.0, 1.0);

    vec2 top_edge = mix(sL, sR, u);
    vec2 bot_edge = mix(hL, hR, u);
    vec2 pos      = mix(top_edge, bot_edge, body_t);

    // ── STEP 4: NECK ANCHOR BIAS ─────────────────────────────────────
    // The upper region of the garment (body_t < 0.1) tends to "float" above
    // the real shoulder line because the mesh top doesn't pin to the clavicle.
    // We apply a downward nudge that is strongest at the very top (body_t=0)
    // and fades to zero by body_t=0.2.
    // Bias direction: towards shoulderMid (downward in Y for typical pose).
    float neck_influence = max(0.0, 1.0 - body_t / 0.2); // 1→0 over first 20%
    float sDist = distance(sL, sR);
    // Pull top rows toward the shoulder midpoint (Y-component only to avoid skew)
    pos.y += (shoulderMid.y - pos.y) * neck_influence * u_neck_bias;

    // ── STEP 5: SLEEVE DEFORMATION ───────────────────────────────────
    // Elbow pull in upper sleeve region (body_t in 0..0.4, u near edges)
    if (body_t < 0.4) {
        float sleeve_str = (1.0 - body_t / 0.4); // 1.0 at top row, 0.0 at 40%

        // Left Sleeve  (u < 0.2)
        if (u < 0.2) {
            float col_f = (1.0 - u / 0.2);
            float pull  = col_f * sleeve_str * 0.45;
            pos += (u_elbow_left - sL) * pull;
        }
        // Right Sleeve (u > 0.8)
        else if (u > 0.8) {
            float col_f = (u - 0.8) / 0.2;
            float pull  = col_f * sleeve_str * 0.45;
            pos += (u_elbow_right - sR) * pull;
        }
    }

    // ── STEP 6: CYLINDER PROJECTION ──────────────────────────────────
    // Curvature is now 0.65 (reduced from ~1.0).
    // theta maps u (0..1) → angle (-PI/2 .. +PI/2), range reduced by 0.8.
    float curvature  = u_params.x * 0.65; // Soften curvature
    float theta      = (u - 0.5) * 3.14159 * 0.8;
    float radius     = sDist * 0.45;
    // cos(0)=1 = center pushed most; cos(PI/2)=0 = edges not pushed
    float z_offset   = cos(theta) * curvature * radius;

    // STEP 7: Clip space
    vec2 clip_xy = (pos / u_resolution) * 2.0 - 1.0;
    // We do NOT flip y here because we flip v_uv.y below. 
    // Flipped y + flipped v_uv = upside down mesh.
    clip_xy.y = -clip_xy.y; 

    float depth  = u_garment_z - z_offset * 0.002;

    gl_Position = vec4(clip_xy, depth, 1.0);

    // Match Canvas Top-to-Bottom coordinate system
    v_uv = a_uv;

    // Procedural cylinder normal for lighting
    v_normal = normalize(vec3(sin(theta), 0.0, cos(theta)));
}
`;

// ── Fragment Shader ────────────────────────────────────────────────────

const FRAGMENT_SHADER_SRC = `#version 300 es
precision highp float;

uniform sampler2D u_color_map;
uniform float u_opacity;
uniform vec4  u_light_cfg;   // [lx, ly, lz, intensity]
uniform float u_brightness;
uniform float u_contrast;

in vec2 v_uv;
in vec3 v_normal;

out vec4 fragColor;

void main() {
    // 1. Albedo — clamp UV to prevent edge artifacts from interpolation
    vec2 safeUV = clamp(v_uv, vec2(0.001), vec2(0.999));
    vec4 base = texture(u_color_map, safeUV);
    if (base.a < 0.05) {
        fragColor = vec4(0.0);
        return;
    }

    base.rgb = (base.rgb - 0.5) * u_contrast + 0.5;
    base.rgb *= u_brightness;

    // 2. Lighting — Wrapped Diffuse (SSS approximation)
    vec3 N = normalize(v_normal);
    vec3 L = normalize(u_light_cfg.xyz);
    vec3 V = vec3(0.0, 0.0, 1.0);

    float wrap = 0.5;
    float NdotL = max(0.0, (dot(N, L) + wrap) / (1.0 + wrap));
    float ambient = 0.40;
    float diffuse = NdotL * u_light_cfg.w;

    // Fresnel/Sheen — energy conserving
    // Use schlick approx: F = f0 + (1-f0)*(1-NdotV)^5
    float f0 = 0.05;
    float NdotV = max(0.0, dot(N, V));
    float fresnel = f0 + (1.0 - f0) * pow(1.0 - NdotV, 2.0);
    // Weight sheen so it doesn't add energy: subtract from diffuse
    float sheenW = fresnel * 0.18;
    vec3  sheen  = vec3(sheenW);
    float combinedDiff = max(0.0, diffuse - sheenW);

    vec3 light = vec3(ambient) + vec3(combinedDiff) + sheen;

    // 3. Soft Edge Alpha (X vignette + bottom hem fade)
    float dx = abs(v_uv.x - 0.5) * 2.0;
    float ax = smoothstep(1.0, 0.85, dx); // fade outer 15%
    float ay = smoothstep(1.0, 0.98, v_uv.y); // gentle bottom fade

    float alpha = base.a * u_opacity * ax * ay;

    fragColor = vec4(base.rgb * light, alpha);
}
`;

// ── Constants ──────────────────────────────────────────────────────────

const GRID_SIZE = 64;
const MAX_DIM = 960;
const UNIFORM_BUF = 64; // Float32Array slots

// Default Fit Stabilization Values
const DEFAULT_TOP_UV = 0.12;
const DEFAULT_BOTTOM_UV = 0.92;
const DEFAULT_SPAN = 0.90;
const DEFAULT_NECK_BIAS = 0.15;
const DEFAULT_CURVATURE = 1.0;  // Actual curvature = 1.0 * 0.65 in shader

// ── WebGLMeshLayer ─────────────────────────────────────────────────────

export class WebGLMeshLayer implements IMeshLayer {
  private gl: WebGL2RenderingContext;
  private canvas: HTMLCanvasElement;
  private program: WebGLProgram | null = null;

  // GPU Resources (all created once)
  private vao: WebGLVertexArrayObject | null = null;
  private iBuf: WebGLBuffer | null = null;
  private uvBuf: WebGLBuffer | null = null;
  private posBuf: WebGLBuffer | null = null;
  private tex: WebGLTexture | null = null;

  // Uniform Locations (cached once at init)
  private L: Record<string, WebGLUniformLocation | null> = {};

  // Persistent uniform data buffer (zero alloc per frame)
  private U = new Float32Array(UNIFORM_BUF);

  // State
  private _lastFrameValid = false;
  private _debugMode = false;
  private _profile: GarmentProfile;
  private _lastTex: HTMLCanvasElement | HTMLImageElement | null = null;

  // Exposed for GarmentFitValidator
  private _lastFit: GarmentFit | null = null;
  // Exposed for GpuParityChecker — exact values uploaded to GPU last frame
  private _lastUniforms: ShaderUniforms | null = null;

  // Resolution tracking
  private _iw = 640;
  private _ih = 480;

  constructor(gl: WebGL2RenderingContext, canvas: HTMLCanvasElement, profile: GarmentProfile) {
    this.gl = gl;
    this.canvas = canvas;
    this._profile = profile;
    this._initProgram();
    this._createGrid();
    this._createTexture();
  }

  // ── IMeshLayer ─────────────────────────────────────────────────────

  get lastFrameValid() { return this._lastFrameValid; }
  get isHighQuality() { return true; }
  get currentGridSize() { return GRID_SIZE; }
  get debugMode() { return this._debugMode; }
  set debugMode(v: boolean) { this._debugMode = v; }
  /** Exposes last-frame garment corners for GarmentFitValidator */
  get lastFit(): GarmentFit | null { return this._lastFit; }
  /** Exposes exact GPU uniform values for GpuParityChecker */
  get lastUniforms(): ShaderUniforms | null { return this._lastUniforms; }
  /** Exposes gl context for LiveFrameValidator readPixels */
  get glContext(): WebGL2RenderingContext { return this.gl; }
  /** Exposes the internal WebGL canvas (not the main canvas) */
  get glCanvas(): HTMLCanvasElement { return this.canvas; }
  get autoAdaptive() { return false; }
  set autoAdaptive(_: boolean) { /* handled by quality scaler */ }

  updateProfile(p: GarmentProfile) { this._profile = p; }

  setGarmentIntelligence(_sleeveEndRow: number, _hemCurvature: number) {
    // Phase 2 will consume these for shader uniforms
  }

  adaptDensity(_fps: number) { return false; } // GPU handles 64x64 without sweat

  buildSourceMesh(_texW: number, _texH: number) {
    // Static UV grid — no dynamic rebuild needed
  }

  buildTargetMesh(pose: PoseMeshInput): boolean {
    const U = this.U;
    const p = this._profile;

    const ls = pose.leftShoulder;
    const rs = pose.rightShoulder;
    const lh = pose.leftHip;
    const rh = pose.rightHip;

    // FIX: Clamp hips to canvas bounds to prevent off-screen mesh stretching
    // (User reported hipY=678 on 480px canvas → divergence/stretching)
    lh.y = Math.min(lh.y, this._ih * 0.95);
    rh.y = Math.min(rh.y, this._ih * 0.95);

    // ── BUG FIX: Sanity check corner coordinates ──
    const topY = Math.min(ls.y, rs.y);
    const botY = Math.max(lh.y, rh.y);
    const leftX = Math.min(ls.x, lh.x);
    const rightX = Math.max(rs.x, rh.x);

    // Throttled log for sanity check
    const gCorners = globalThis as unknown as { __meshDebugCount?: number };
    if ((gCorners.__meshDebugCount ?? 0) % 60 === 0) {
      console.log('[CORNERS] topY:', topY.toFixed(1), 'botY:', botY.toFixed(1),
        'leftX:', leftX.toFixed(1), 'rightX:', rightX.toFixed(1));
    }

    if (topY >= botY) {
      console.warn('[MESH] ERROR: Top is below bottom! topY:', topY, 'botY:', botY);
      return false;
    }
    if (leftX >= rightX) {
      console.warn('[MESH] ERROR: Left is right of right! leftX:', leftX, 'rightX:', rightX);
      return false;
    }

    // ── Shoulder & Hip centers
    const sCx = (ls.x + rs.x) * 0.5;
    const sCy = (ls.y + rs.y) * 0.5;
    const hCx = (lh.x + rh.x) * 0.5;
    const hCy = (lh.y + rh.y) * 0.5;
    const sDist = Math.hypot(rs.x - ls.x, rs.y - ls.y);

    // ── Garment width from profile
    const gTopW = sDist * p.widthScale;
    const gBotW = Math.max(Math.hypot(rh.x - lh.x, rh.y - lh.y), sDist * 0.85) * p.widthScale;

    // ── Orientation (shoulder axis direction for angled bodies)
    const sDx = rs.x - ls.x;
    const sDy = rs.y - ls.y;
    const len = Math.hypot(sDx, sDy) || 1;
    const dirX = sDx / len;
    const dirY = sDy / len;

    // ── Corners (full-span, span compression happens in shader)
    const collarLift = sDist * 0.12; // lift collar to neck base
    const tlx = sCx - dirX * (gTopW * 0.5);
    const tly = sCy - dirY * (gTopW * 0.5) - collarLift;
    const trx = sCx + dirX * (gTopW * 0.5);
    const tryV = sCy + dirY * (gTopW * 0.5) - collarLift;

    const blx = hCx - dirX * (gBotW * 0.5);
    const bly = hCy - dirY * (gBotW * 0.5);
    const brx = hCx + dirX * (gBotW * 0.5);
    const bry = hCy + dirY * (gBotW * 0.5);

    // ── Elbows (fallback to shoulder if invisible)
    const elx = pose.leftElbow ? pose.leftElbow.x : tlx - sDist * 0.15;
    const ely = pose.leftElbow ? pose.leftElbow.y : tly + sDist * 0.4;
    const erx = pose.rightElbow ? pose.rightElbow.x : trx + sDist * 0.15;
    const ery = pose.rightElbow ? pose.rightElbow.y : tryV + sDist * 0.4;

    // ── Write to Uniform Buffer (Zero Alloc)
    // Slot map (2 floats per vec2):
    //  0-1  shoulder_left   2-3  shoulder_right
    //  4-5  hip_left        6-7  hip_right
    //  8-9  elbow_left     10-11 elbow_right
    // 12    garment_top_uv 13    garment_bottom_uv
    // 14    span_scale     15    neck_bias
    // 16    params.xyzw (curvature, reserved, reserved, reserved)
    // 20    light xyzw

    U[0] = tlx; U[1] = tly;
    U[2] = trx; U[3] = tryV;
    U[4] = blx; U[5] = bly;
    U[6] = brx; U[7] = bry;
    U[8] = elx; U[9] = ely;
    U[10] = erx; U[11] = ery;

    // Fit stabilization - Adaptive
    // 1. Adaptive Span: align visual shoulders to mesh endpoints
    const shoulderEx = p.anchors.rightShoulder.x - p.anchors.leftShoulder.x;
    const targetSpan = 1.0 / (p.widthScale * shoulderEx);
    // Fix Issue 1: Apply correction factor (1.0/1.197 ~ 0.83) for reported 20% overshoot
    U[14] = Math.max(0.6, Math.min(1.2, targetSpan * 0.83));

    // 2. Adaptive Neck Bias: scales with torso aspect ratio
    //    Base 0.15 is for ratio ~1.5. linear scaling: bias = 0.10 * ratio
    const torsoH = Math.abs(hCy - sCy) || sDist;
    const ratio = torsoH / sDist;
    U[15] = Math.max(0.05, Math.min(0.4, 0.10 * ratio));

    U[12] = DEFAULT_TOP_UV;
    U[13] = DEFAULT_BOTTOM_UV;

    // Params
    U[16] = DEFAULT_CURVATURE; // *0.65 applied in shader
    U[17] = 0.0;
    U[18] = 0.0;
    U[19] = 0.0;

    // Light: slightly top-right frontal
    U[20] = 0.25; U[21] = 0.25; U[22] = 1.0; U[23] = 1.05;

    // Expose fit corners for validator
    this._lastFit = {
      tlx, tly, trx, tryV, blx, bly, brx, bry,
      shoulderDist: sDist,
      canvasW: this._iw,
      canvasH: this._ih,
    };

    // Expose exact GPU uniform snapshot for parity checker
    this._lastUniforms = {
      shoulder_left: [U[0], U[1]],
      shoulder_right: [U[2], U[3]],
      hip_left: [U[4], U[5]],
      hip_right: [U[6], U[7]],
      elbow_left: [U[8], U[9]],
      elbow_right: [U[10], U[11]],
      garment_top_uv: U[12],
      garment_bottom_uv: U[13],
      span_scale: U[14],
      neck_bias: U[15],
      curvature: U[16],
      garment_z: 0.5,  // default depth not in U[]
      resolution: [this._iw, this._ih],
    };

    this._lastFrameValid = true;

    // ── BUG C diagnostic: log mesh corners every 60 frames ──
    const gMeshDef = globalThis as unknown as { __meshDebugCount?: number };
    gMeshDef.__meshDebugCount = (gMeshDef.__meshDebugCount ?? 0) + 1;
    if (gMeshDef.__meshDebugCount % 60 === 0) {
      console.log(`[MESH] topLeft: (${tlx.toFixed(1)}, ${tly.toFixed(1)})  topRight: (${trx.toFixed(1)}, ${tryV.toFixed(1)})`);
      console.log(`[MESH] botLeft: (${blx.toFixed(1)}, ${bly.toFixed(1)})  botRight: (${brx.toFixed(1)}, ${bry.toFixed(1)})`);
      console.log(`[MESH] canvas: ${this._iw}x${this._ih}  shoulderDist: ${sDist.toFixed(1)}`);
    }

    return true;
  }

  // ── Render ─────────────────────────────────────────────────────────

  render(
    renderer: IRenderer,
    texture: HTMLCanvasElement | HTMLImageElement,
    opacity: number,
    occlusions?: { x: number; y: number; w: number; h: number }[]
  ): void {
    if (!this._lastFrameValid || !this.program) return;

    const gl = this.gl;
    const ctx = renderer.getContext();
    const rw = ctx.canvas.width;
    const rh = ctx.canvas.height;

    // ── Resolution Cap
    const scale = Math.min(1.0, MAX_DIM / Math.max(rw, rh, 1));
    const iw = Math.max(1, Math.floor(rw * scale));
    const ih = Math.max(1, Math.floor(rh * scale));

    if (this._iw !== iw || this._ih !== ih) {
      this._iw = iw;
      this._ih = ih;
      this.canvas.width = iw;
      this.canvas.height = ih;
    }

    // ── Texture Upload (only on change)
    if (texture !== this._lastTex) {
      this._uploadTexture(texture);
      this._lastTex = texture;
    }

    // ── Draw
    gl.viewport(0, 0, iw, ih);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.BLEND);
    // Use separate blend func to avoid squaring alpha
    // Color: RGB * A + Dst * (1-A)  (Standard Over)
    // Alpha: A * 1 + Dst * (1-A)    (Keep Source Alpha straight, Dst assumed 0 typically)
    gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);

    gl.useProgram(this.program);
    gl.bindVertexArray(this.vao);

    // ── Uniforms (all via cached locations, zero alloc)
    const U = this.U;
    const L = this.L;

    gl.uniform2f(L.u_shoulder_left, U[0], U[1]);
    gl.uniform2f(L.u_shoulder_right, U[2], U[3]);
    gl.uniform2f(L.u_hip_left, U[4], U[5]);
    gl.uniform2f(L.u_hip_right, U[6], U[7]);
    gl.uniform2f(L.u_elbow_left, U[8], U[9]);
    gl.uniform2f(L.u_elbow_right, U[10], U[11]);

    gl.uniform1f(L.u_garment_top_uv, U[12]);
    gl.uniform1f(L.u_garment_bottom_uv, U[13]);
    gl.uniform1f(L.u_span_scale, U[14]);
    gl.uniform1f(L.u_neck_bias, U[15]);

    gl.uniform4f(L.u_params, U[16], U[17], U[18], U[19]);
    gl.uniform4f(L.u_light_cfg, U[20], U[21], U[22], U[23]);

    // Pass LOGICAL resolution so pixel coords match canvas
    gl.uniform2f(L.u_resolution, rw, rh);
    gl.uniform1f(L.u_garment_z, 0.5);

    gl.uniform1f(L.u_opacity, opacity);
    gl.uniform1f(L.u_brightness, renderer.brightness);
    gl.uniform1f(L.u_contrast, renderer.contrast);
    gl.uniform1i(L.u_color_map, 0);

    // Draw the 64x64 mesh
    const numIndices = GRID_SIZE * GRID_SIZE * 6;
    gl.drawElements(gl.TRIANGLES, numIndices, gl.UNSIGNED_SHORT, 0);

    gl.bindVertexArray(null);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.BLEND);

    // ── Composite onto 2D canvas
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1.0;
    ctx.drawImage(this.canvas, 0, 0, rw, rh);
    ctx.restore();

    // ── Occlusion (Phase 1 legacy — Phase 2 will remove this)
    if (occlusions && occlusions.length > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = '#000';
      for (let i = 0; i < occlusions.length; i++) {
        const o = occlusions[i];
        ctx.beginPath();
        ctx.ellipse(o.x + o.w * 0.5, o.y + o.h * 0.5, o.w * 0.5, o.h * 0.5, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  // ── Private Init Helpers ───────────────────────────────────────────

  private _initProgram() {
    const gl = this.gl;
    const vs = this._compile(gl.VERTEX_SHADER, VERTEX_SHADER_SRC);
    const fs = this._compile(gl.FRAGMENT_SHADER, FRAGMENT_SHADER_SRC);
    if (!vs || !fs) throw new Error('[WGL] Shader compile failed');

    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);

    // Bind attribute locations before linking
    gl.bindAttribLocation(prog, 0, 'a_position');
    gl.bindAttribLocation(prog, 1, 'a_uv');

    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      throw new Error('[WGL] Link failed: ' + gl.getProgramInfoLog(prog));
    }
    this.program = prog;

    // Cache ALL uniform locations up front (once only)
    const u = (n: string) => gl.getUniformLocation(prog, n);
    this.L = {
      u_shoulder_left: u('u_shoulder_left'),
      u_shoulder_right: u('u_shoulder_right'),
      u_hip_left: u('u_hip_left'),
      u_hip_right: u('u_hip_right'),
      u_elbow_left: u('u_elbow_left'),
      u_elbow_right: u('u_elbow_right'),
      u_garment_top_uv: u('u_garment_top_uv'),
      u_garment_bottom_uv: u('u_garment_bottom_uv'),
      u_span_scale: u('u_span_scale'),
      u_neck_bias: u('u_neck_bias'),
      u_params: u('u_params'),
      u_light_cfg: u('u_light_cfg'),
      u_resolution: u('u_resolution'),
      u_garment_z: u('u_garment_z'),
      u_opacity: u('u_opacity'),
      u_brightness: u('u_brightness'),
      u_contrast: u('u_contrast'),
      u_color_map: u('u_color_map'),
    };

    gl.deleteShader(vs);
    gl.deleteShader(fs);
  }

  private _createGrid() {
    const gl = this.gl;
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];

    for (let y = 0; y <= GRID_SIZE; y++) {
      for (let x = 0; x <= GRID_SIZE; x++) {
        const u = x / GRID_SIZE;
        const v = y / GRID_SIZE;
        positions.push(u, v);
        uvs.push(u, v);
      }
    }
    for (let y = 0; y < GRID_SIZE; y++) {
      for (let x = 0; x < GRID_SIZE; x++) {
        const i0 = y * (GRID_SIZE + 1) + x;
        indices.push(i0, i0 + GRID_SIZE + 1, i0 + 1);
        indices.push(i0 + 1, i0 + GRID_SIZE + 1, i0 + GRID_SIZE + 2);
      }
    }

    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);

    // Position Buffer (a_position, loc 0)
    this.posBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    // UV Buffer (a_uv, loc 1)
    this.uvBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(uvs), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 0, 0);

    // Index Buffer
    this.iBuf = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.iBuf);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

    gl.bindVertexArray(null);
  }

  private _createTexture() {
    const gl = this.gl;
    this.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    // Placeholder 1x1 transparent pixel
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));
  }

  private _uploadTexture(src: HTMLCanvasElement | HTMLImageElement) {
    const gl = this.gl;
    // VERY IMPORTANT: Tell WebGL to premultiply the alpha channel during upload.
    // If we don't do this, the LINEAR texture filter will interpolate the colored edge
    // of the garment with the pure black (0,0,0,0) transparent background, causing 
    // a dark "checkerboard" or "grid" artifact across the mesh when deformed.
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);

    // ── Inspect Alpha State ──────────────────────────────────────────
    const premult = gl.getParameter(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL);
    console.log(`[WebGL] Upload Texture: ${src.width}x${src.height} | UNPACK_PREMULTIPLY=${premult}`);

    // Read back a sample pixel (e.g. center) to verify alpha
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.tex, 0);
    const pix = new Uint8Array(4);
    // Read center pixel
    const cx = Math.floor(src.width / 2);
    const cy = Math.floor(src.height / 2);
    gl.readPixels(cx, cy, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pix);
    console.log(`[WebGL] Sample Pixel (Center): R=${pix[0]} G=${pix[1]} B=${pix[2]} A=${pix[3]}`);

    gl.deleteFramebuffer(fb);
    // Restore default framebuffer (or null, render loop will re-bind)
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  private _compile(type: number, src: string): WebGLShader | null {
    const gl = this.gl;
    const s = gl.createShader(type);
    if (!s) return null;
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      console.error('[WGL] Shader error:', gl.getShaderInfoLog(s));
      gl.deleteShader(s);
      return null;
    }
    return s;
  }
}

// ── Factory ────────────────────────────────────────────────────────────

export function isWebGLSupported(): boolean {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('experimental-webgl'));
  } catch { return false; }
}

/**
 * Creates a mesh layer — prefers WebGL 2, falls back to Canvas 2D MeshWarper.
 */
export function createMeshLayer(canvas: HTMLCanvasElement, profile: GarmentProfile): IMeshLayer {
  const offscreen = document.createElement('canvas');
  offscreen.width = canvas.width || 640;
  offscreen.height = canvas.height || 480;

  const gl = offscreen.getContext('webgl2', {
    alpha: true,
    premultipliedAlpha: false,   // Fragment shader outputs straight alpha
    depth: true,
    stencil: false,
    antialias: false,
    powerPreference: 'high-performance',
    preserveDrawingBuffer: false,
  }) as WebGL2RenderingContext | null;

  if (gl) {
    try {
      return new WebGLMeshLayer(gl, offscreen, profile);
    } catch (e) {
      console.warn('[AR Engine] WebGL init failed, falling back to Canvas 2D:', e);
    }
  }

  return new MeshWarper(profile);
}

export { MeshWarper as CanvasMeshLayer };
