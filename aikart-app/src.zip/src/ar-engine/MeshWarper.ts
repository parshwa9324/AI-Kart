/**
 * MeshWarper.ts — Hardened Geometry Engine
 *
 * Deforms a garment texture onto pose landmarks via adaptive-density
 * triangle mesh with stability safeguards.
 *
 * Steps implemented:
 * 1. Triangle inversion detection + per-vertex movement clamp + elbow dampening
 * 2. Adaptive density: 8×8 (normal) / 12×12 (high-quality), FPS-based auto-switch
 * 3. Sleeve region isolation: elbow influence only on upper 40% of mesh
 * 4. Neck alignment: nose landmark drives collar vertical position
 * 5. Realistic width: shoulder→hip gradient interpolation per row
 * 6. Performance: Float32Array buffers, precomputed quad topology, zero alloc in warp loop
 * 7. Safety: invalid geometry auto-detected, returns false to trigger fallback
 */

import type { GarmentProfile } from './GarmentConfig';
import { IRenderer } from './interfaces/IRenderer';
import { IMeshLayer, PoseMeshInput } from './interfaces/IMeshLayer';

// PoseMeshInput moved to IMeshLayer interface

// ── Topology (precomputed once per density change) ────────────

interface Topology {
  gridSize: number;
  verts: number;       // gridSize + 1
  totalVerts: number;  // verts * verts
  totalQuads: number;  // gridSize * gridSize
  // Per-quad: 4 vertex indices packed [i00, i10, i01, i11]
  quadIndices: Uint16Array;
}

function buildTopology(gridSize: number): Topology {
  const verts = gridSize + 1;
  const totalQuads = gridSize * gridSize;
  const quadIndices = new Uint16Array(totalQuads * 4);
  let qi = 0;
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      quadIndices[qi++] = row * verts + col;          // i00
      quadIndices[qi++] = row * verts + col + 1;      // i10
      quadIndices[qi++] = (row + 1) * verts + col;    // i01
      quadIndices[qi++] = (row + 1) * verts + col + 1;// i11
    }
  }
  return { gridSize, verts, totalVerts: verts * verts, totalQuads, quadIndices };
}

// ── Constants ─────────────────────────────────────────────────

const MAX_VERTEX_MOVE_PER_FRAME = 12;
const ELBOW_DAMPEN_VELOCITY_THRESHOLD = 40;
const DEFAULT_SLEEVE_END = 0.4;
const MAX_STRETCH_RATIO = 1.15; // Step 5: texture density preservation

// Phase 2 constants
const GRAVITY_PULL_PX = 1.5;     // max downward offset for bottom rows
const MAX_SHEAR_RATIO = 2.5;     // quad diagonal ratio clamp
const ROW_WEIGHT_TOP = 1.0;      // shoulder following strength (rows 0-30%)
const ROW_WEIGHT_MID = 0.7;      // mid-torso (rows 30-70%)
const ROW_WEIGHT_BOT = 0.4;      // hem region (rows 70-100%)

export class MeshWarper implements IMeshLayer {
  private profile: GarmentProfile;

  // Current topo (switches between 8×8 and 12×12)
  private topo: Topology;
  private topo8: Topology;
  private topo12: Topology;

  // Vertex buffers: [x0, y0, x1, y1, ...] interleaved
  private srcBuf!: Float32Array;
  private dstBuf!: Float32Array;
  private prevDstBuf!: Float32Array;  // previous frame for movement clamping

  private hasPrevFrame = false;
  private lastPoseHash = 0;  // numeric hash for speed

  // Adaptive density state
  private _highQuality = false;
  private _autoAdaptive = true;
  private _texW = 0;
  private _texH = 0;

  // Elbow velocity tracking for dampening
  private prevLeftElbow: { x: number; y: number } | null = null;
  private prevRightElbow: { x: number; y: number } | null = null;

  // Garment intelligence (from GarmentAnalyzer)
  private _sleeveEndRow = DEFAULT_SLEEVE_END;
  private _hemCurvature = 0;

  // Debug mode
  private _debugMode = false;

  // Step 7: geometry validity flag
  private _lastFrameValid = true;
  get lastFrameValid(): boolean { return this._lastFrameValid; }
  get debugMode(): boolean { return this._debugMode; }
  set debugMode(v: boolean) { this._debugMode = v; }

  constructor(profile: GarmentProfile) {
    this.profile = profile;
    this.topo8 = buildTopology(8);
    this.topo12 = buildTopology(12);
    this.topo = this.topo8;
    this.allocateBuffers(this.topo);
  }

  get isHighQuality(): boolean { return this._highQuality; }
  get currentGridSize(): number { return this.topo.gridSize; }

  set autoAdaptive(v: boolean) { this._autoAdaptive = v; }

  updateProfile(profile: GarmentProfile): void {
    this.profile = profile;
    this.lastPoseHash = 0;
    this.hasPrevFrame = false;
  }

  /** Set garment intelligence parameters from GarmentAnalyzer */
  setGarmentIntelligence(sleeveEndRow: number, hemCurvature: number): void {
    this._sleeveEndRow = Math.max(0.1, Math.min(0.7, sleeveEndRow));
    this._hemCurvature = hemCurvature;
    this.lastPoseHash = 0; // force recompute
  }

  /**
   * Step 2: Switch density based on FPS. Called by Engine each frame.
   * Returns true if density changed (needs source mesh rebuild).
   */
  adaptDensity(fps: number): boolean {
    if (!this._autoAdaptive) return false;

    const wantHigh = fps > 28;
    const wantLow = fps < 22;

    if (wantHigh && !this._highQuality) {
      return this.setDensity(true);
    }
    if (wantLow && this._highQuality) {
      return this.setDensity(false);
    }
    return false;
  }

  /** Force specific density mode */
  setDensity(highQuality: boolean): boolean {
    if (highQuality === this._highQuality) return false;
    this._highQuality = highQuality;
    this.topo = highQuality ? this.topo12 : this.topo8;
    this.allocateBuffers(this.topo);
    this.hasPrevFrame = false;
    this.lastPoseHash = 0;
    // Rebuild source mesh with current texture dimensions
    if (this._texW > 0) this.buildSourceMesh(this._texW, this._texH);
    return true;
  }

  /**
   * Build source mesh (uniform grid over texture).
   * Called once when garment changes or density switches.
   */
  buildSourceMesh(texW: number, texH: number): void {
    this._texW = texW;
    this._texH = texH;
    const { verts, gridSize } = this.topo;
    for (let row = 0; row < verts; row++) {
      for (let col = 0; col < verts; col++) {
        const bi = (row * verts + col) * 2;
        this.srcBuf[bi] = (col / gridSize) * texW;
        this.srcBuf[bi + 1] = (row / gridSize) * texH;
      }
    }
  }

  /**
   * Build target mesh deformed by pose data.
   * Returns true if mesh is valid and renderable.
   * Returns false if geometry is invalid → Engine should fallback. (Step 7)
   * 
   * Phase 1: yaw compression, torso tilt, ear-collar alignment
   * Phase 2: row-weighted motion, gravity pull, elbow angle, shear clamp
   */
  buildTargetMesh(pose: PoseMeshInput): boolean {
    const hash = this.numericHash(pose);
    if (hash === this.lastPoseHash && this.hasPrevFrame) {
      this._lastFrameValid = true;
      return true; // no change, previous frame still valid
    }
    this.lastPoseHash = hash;

    const { verts, gridSize } = this.topo;
    const ls = pose.leftShoulder;
    const rs = pose.rightShoulder;
    const lh = pose.leftHip;
    const rh = pose.rightHip;

    // Core measurements
    const shoulderMidX = (ls.x + rs.x) * 0.5;
    const shoulderMidY = (ls.y + rs.y) * 0.5;
    const hipMidX = (lh.x + rh.x) * 0.5;
    const hipMidY = (lh.y + rh.y) * 0.5;
    const shoulderDist = Math.hypot(rs.x - ls.x, rs.y - ls.y);
    const hipDist = Math.hypot(rh.x - lh.x, rh.y - lh.y);
    const shoulderAngle = Math.atan2(rs.y - ls.y, rs.x - ls.x);
    const cosA = Math.cos(shoulderAngle);
    const sinA = Math.sin(shoulderAngle);
    const applyRotation = Math.abs(shoulderAngle) > 0.008;

    // Phase 1: Yaw compression (narrows garment when body rotated)
    const yawFactor = pose.yawCompression ?? 1.0;

    // Phase 2: Depth-based width compression (from shoulder/hip z)
    const depthWidthScale = pose.depthWidthScale ?? 1.0;

    // Phase 1/2: Torso pitch scaling (shorten garment when leaning forward), clamped ±4%
    const rawPitchScale = pose.torsoPitchScale ?? 1.0;
    const pitchScale = rawPitchScale > 1.04 ? 1.04 : (rawPitchScale < 0.96 ? 0.96 : rawPitchScale);

    // Width gradient: shoulder width at top, hip width at bottom
    const shoulderW = shoulderDist * this.profile.widthScale * yawFactor * depthWidthScale;
    const hipW = hipDist * this.profile.widthScale * yawFactor * depthWidthScale;

    // Torso length with pitch adjustment
    const torsoLen = Math.hypot(hipMidX - shoulderMidX, hipMidY - shoulderMidY);
    const garmentH = torsoLen * this.profile.heightScale * pitchScale;

    // Phase 1: Collar alignment — prefer ear-based collarY, fallback to nose, then fixed
    let neckOffsetY: number;
    if (pose.collarY !== undefined && pose.collarY > 0) {
      neckOffsetY = pose.collarY;
    } else if (pose.noseY !== undefined && pose.noseY > 0) {
      const noseToShoulder = shoulderMidY - pose.noseY;
      neckOffsetY = noseToShoulder > 10 ? noseToShoulder * 0.35 : garmentH * 0.08;
    } else {
      neckOffsetY = garmentH * 0.08;
    }

    // Elbow velocity dampening
    const leftElbowDamp = this.computeElbowDampen(pose.leftElbow, this.prevLeftElbow);
    const rightElbowDamp = this.computeElbowDampen(pose.rightElbow, this.prevRightElbow);
    this.prevLeftElbow = pose.leftElbow ? { x: pose.leftElbow.x, y: pose.leftElbow.y } : null;
    this.prevRightElbow = pose.rightElbow ? { x: pose.rightElbow.x, y: pose.rightElbow.y } : null;

    // Phase 2: Elbow angles for sleeve compression
    let leftElbowAngle = 0;
    let rightElbowAngle = 0;
    if (pose.leftElbow) {
      leftElbowAngle = Math.atan2(pose.leftElbow.y - ls.y, pose.leftElbow.x - ls.x);
    }
    if (pose.rightElbow) {
      rightElbowAngle = Math.atan2(pose.rightElbow.y - rs.y, pose.rightElbow.x - rs.x);
    }

    // Sleeve region boundary from garment intelligence
    const sleeveEndRow = Math.ceil(gridSize * this._sleeveEndRow);

    // Hem curvature: bottom 15% of rows
    const hemRows = Math.max(1, Math.floor(gridSize * 0.15));

    // Cylinder radius for 2.5D horizontal curvature
    const radius = shoulderDist > 1 ? shoulderDist / 2.2 : 0;
    const radiusInv = radius > 0 ? 1 / radius : 0;
    // Blend curvature with yaw: more frontal → stronger wrap
    const curvatureBlend = radius > 0
      ? (1.1 - Math.min(1, yawFactor)) * 0.7 + 0.3
      : 0;

    // ── Compute all vertices ──────────────────────────────

    for (let row = 0; row < verts; row++) {
      const t = row / gridSize; // 0 = top, 1 = bottom

      // Phase 2: Row-weighted motion factor
      let rowWeight: number;
      if (t < 0.3) rowWeight = ROW_WEIGHT_TOP;
      else if (t < 0.7) rowWeight = ROW_WEIGHT_TOP + (ROW_WEIGHT_MID - ROW_WEIGHT_TOP) * ((t - 0.3) / 0.4);
      else rowWeight = ROW_WEIGHT_MID + (ROW_WEIGHT_BOT - ROW_WEIGHT_MID) * ((t - 0.7) / 0.3);

      // Width gradient: shoulder → hip, modulated by row weight
      const rowWidth = shoulderW * (1 - t) + hipW * t;

      // Center interpolates shoulder→hip with row weight dampening
      const baseRowCenterX = shoulderMidX * (1 - t) + hipMidX * t;
      const rowCenterX = shoulderMidX + (baseRowCenterX - shoulderMidX) * rowWeight;
      const rowY = (shoulderMidY - neckOffsetY) * (1 - t) + (hipMidY + garmentH * 0.15) * t;

      for (let col = 0; col < verts; col++) {
        const s = col / gridSize;
        const bi = (row * verts + col) * 2;

        const localX = (s - 0.5) * rowWidth;
        let x = rowCenterX + localX;
        let y = rowY;

        // Phase 1: Cylinder projection — horizontal curvature on torso
        if (radius > 0 && curvatureBlend > 0) {
          const theta = localX * radiusInv;
          const projectedX = radius * Math.sin(theta);
          const deltaX = (projectedX - localX) * curvatureBlend;
          x += deltaX;
        }

        // Rotation
        if (applyRotation) {
          const dx = x - shoulderMidX;
          const dy = y - shoulderMidY;
          x = shoulderMidX + dx * cosA - dy * sinA;
          y = shoulderMidY + dx * sinA + dy * cosA;
        }

        // Sleeve deformation — ONLY in sleeve region
        if (row <= sleeveEndRow) {
          const rowFactor = row <= 1 ? 0.1 : (row <= sleeveEndRow ? 0.3 : 0);

          // Left sleeve: col 0..1
          if (col <= 1 && pose.leftElbow && rowFactor > 0) {
            const colFactor = 1 - col / 2;
            const inf = rowFactor * colFactor * leftElbowDamp;
            x += (pose.leftElbow.x - ls.x) * inf;
            y += (pose.leftElbow.y - ls.y) * inf;

            // Phase 2: Inward elbow bend → compress sleeve width
            // If elbow angle points inward (toward body center), compress
            const inwardFactor = Math.max(0, Math.sin(leftElbowAngle));
            if (inwardFactor > 0.2) {
              x += (rowCenterX - x) * inwardFactor * 0.15 * inf;
            }
          }

          // Right sleeve: col (gridSize-1)..gridSize
          if (col >= gridSize - 1 && pose.rightElbow && rowFactor > 0) {
            const colFactor = (col - (gridSize - 2)) / 2;
            const inf = rowFactor * colFactor * rightElbowDamp;
            x += (pose.rightElbow.x - rs.x) * inf;
            y += (pose.rightElbow.y - rs.y) * inf;

            // Phase 2: Inward elbow bend
            const inwardFactor = Math.max(0, -Math.sin(rightElbowAngle));
            if (inwardFactor > 0.2) {
              x += (rowCenterX - x) * inwardFactor * 0.15 * inf;
            }
          }
        }

        // Per-vertex movement clamp against previous frame
        if (this.hasPrevFrame) {
          const prevX = this.prevDstBuf[bi];
          const prevY = this.prevDstBuf[bi + 1];
          const dx = x - prevX;
          const dy = y - prevY;
          const moveDist = Math.sqrt(dx * dx + dy * dy);
          if (moveDist > MAX_VERTEX_MOVE_PER_FRAME) {
            const scale = MAX_VERTEX_MOVE_PER_FRAME / moveDist;
            x = prevX + dx * scale;
            y = prevY + dy * scale;
          }
        }

        // Hem curvature deformation (bottom rows only)
        if (this._hemCurvature !== 0 && row >= gridSize - hemRows) {
          const hemT = (row - (gridSize - hemRows)) / hemRows;
          const colCenter = (s - 0.5) * 2; // -1→+1
          const curvePx = this._hemCurvature * shoulderDist * hemT * (1 - colCenter * colCenter);
          y += curvePx;
        }

        // Phase 2: Gravity pull on bottom 2 rows
        if (row >= gridSize - 1) {
          const gravityT = (row - (gridSize - 2)) / 2; // 0→1 over last 2 rows
          y += GRAVITY_PULL_PX * Math.min(gravityT, 1.0);
        }

        this.dstBuf[bi] = x;
        this.dstBuf[bi + 1] = y;
      }
    }

    // Phase 2: Per-quad shear clamp
    const qi = this.topo.quadIndices;
    for (let q = 0; q < this.topo.totalQuads; q++) {
      const q4 = q * 4;
      const i00 = qi[q4] * 2, i10 = qi[q4 + 1] * 2;
      const i01 = qi[q4 + 2] * 2, i11 = qi[q4 + 3] * 2;

      // Check quad diagonals for excessive shear
      const d1 = Math.sqrt((this.dstBuf[i11] - this.dstBuf[i00]) ** 2 + (this.dstBuf[i11 + 1] - this.dstBuf[i00 + 1]) ** 2);
      const d2 = Math.sqrt((this.dstBuf[i10] - this.dstBuf[i01]) ** 2 + (this.dstBuf[i10 + 1] - this.dstBuf[i01 + 1]) ** 2);
      if (d1 > 0 && d2 > 0) {
        const ratio = Math.max(d1 / d2, d2 / d1);
        if (ratio > MAX_SHEAR_RATIO) {
          // Pull all 4 vertices toward quad center to reduce shear
          const cx = (this.dstBuf[i00] + this.dstBuf[i10] + this.dstBuf[i01] + this.dstBuf[i11]) * 0.25;
          const cy = (this.dstBuf[i00 + 1] + this.dstBuf[i10 + 1] + this.dstBuf[i01 + 1] + this.dstBuf[i11 + 1]) * 0.25;
          const pullFactor = 1.0 - MAX_SHEAR_RATIO / ratio; // how much to pull (0→1)
          const pull = pullFactor * 0.3; // gentle correction
          // Unrolled to avoid array allocation
          this.dstBuf[i00] += (cx - this.dstBuf[i00]) * pull;
          this.dstBuf[i00 + 1] += (cy - this.dstBuf[i00 + 1]) * pull;
          this.dstBuf[i10] += (cx - this.dstBuf[i10]) * pull;
          this.dstBuf[i10 + 1] += (cy - this.dstBuf[i10 + 1]) * pull;
          this.dstBuf[i01] += (cx - this.dstBuf[i01]) * pull;
          this.dstBuf[i01 + 1] += (cy - this.dstBuf[i01 + 1]) * pull;
          this.dstBuf[i11] += (cx - this.dstBuf[i11]) * pull;
          this.dstBuf[i11 + 1] += (cy - this.dstBuf[i11 + 1]) * pull;
        }
      }
    }

    // Triangle inversion detection — check all quads
    let invalidCount = 0;
    for (let q = 0; q < this.topo.totalQuads; q++) {
      const q4 = q * 4;
      const a00 = qi[q4] * 2, a10 = qi[q4 + 1] * 2;
      const a01 = qi[q4 + 2] * 2, a11 = qi[q4 + 3] * 2;

      const area1 = (this.dstBuf[a10] - this.dstBuf[a00]) * (this.dstBuf[a01 + 1] - this.dstBuf[a00 + 1])
                   - (this.dstBuf[a01] - this.dstBuf[a00]) * (this.dstBuf[a10 + 1] - this.dstBuf[a00 + 1]);
      const area2 = (this.dstBuf[a11] - this.dstBuf[a10]) * (this.dstBuf[a01 + 1] - this.dstBuf[a10 + 1])
                   - (this.dstBuf[a01] - this.dstBuf[a10]) * (this.dstBuf[a11 + 1] - this.dstBuf[a10 + 1]);

      if (area1 < 0 || area2 < 0) {
        invalidCount++;
        if (this.hasPrevFrame) {
          this.dstBuf[a00] = this.prevDstBuf[a00];
          this.dstBuf[a00 + 1] = this.prevDstBuf[a00 + 1];
          this.dstBuf[a10] = this.prevDstBuf[a10];
          this.dstBuf[a10 + 1] = this.prevDstBuf[a10 + 1];
          this.dstBuf[a01] = this.prevDstBuf[a01];
          this.dstBuf[a01 + 1] = this.prevDstBuf[a01 + 1];
          this.dstBuf[a11] = this.prevDstBuf[a11];
          this.dstBuf[a11 + 1] = this.prevDstBuf[a11 + 1];
        }
      }
    }

    // If >25% of quads are invalid, this frame is garbage
    this._lastFrameValid = invalidCount < this.topo.totalQuads * 0.25;

    // Save current as previous for next frame's movement clamping
    this.prevDstBuf.set(this.dstBuf);
    this.hasPrevFrame = true;

    return this._lastFrameValid;
  }

  /**
   * Render the warped mesh. Zero alloc, precomputed topology.
   * Phase 5: Texture density preservation — skips triangles exceeding 1.15× stretch.
   * Phase 3: Brightness/Contrast from Renderer.
   * Phase 4: Occlusion masks.
   */
  render(
    renderer: IRenderer,
    texture: HTMLCanvasElement | HTMLImageElement,
    opacity: number,
    occlusions?: { x: number; y: number; w: number; h: number }[]
  ): void {
    if (!this._lastFrameValid) return;

    const ctx = renderer.getContext();
    ctx.save();
    
    // Phase 3: Brightness/Contrast matching
    const br = Math.round(renderer.brightness * 100) / 100;
    const ct = Math.round(renderer.contrast * 100) / 100;
    ctx.filter = `brightness(${br}) contrast(${ct})`;

    ctx.globalAlpha = opacity;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'medium';

    const qi = this.topo.quadIndices;
    const src = this.srcBuf;
    const dst = this.dstBuf;

    for (let q = 0; q < this.topo.totalQuads; q++) {
      const q4 = q * 4;
      const a00 = qi[q4] * 2, a10 = qi[q4 + 1] * 2;
      const a01 = qi[q4 + 2] * 2, a11 = qi[q4 + 3] * 2;

      // Triangle 1: i00, i10, i01
      this.renderTriClamped(ctx, texture,
        src[a00], src[a00 + 1], src[a10], src[a10 + 1], src[a01], src[a01 + 1],
        dst[a00], dst[a00 + 1], dst[a10], dst[a10 + 1], dst[a01], dst[a01 + 1]
      );

      // Triangle 2: i10, i11, i01
      this.renderTriClamped(ctx, texture,
        src[a10], src[a10 + 1], src[a11], src[a11 + 1], src[a01], src[a01 + 1],
        dst[a10], dst[a10 + 1], dst[a11], dst[a11 + 1], dst[a01], dst[a01 + 1]
      );
    }

    ctx.restore();

    // Phase 4: Occlusion mask — clear arm regions crossing the body with 2px feather
    if (occlusions && occlusions.length > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = '#000';
      for (let i = 0; i < occlusions.length; i++) {
        const occ = occlusions[i];
        const cx = occ.x + occ.w * 0.5;
        const cy = occ.y + occ.h * 0.5;
        const rx = occ.w * 0.5;
        const ry = occ.h * 0.5;

        // Core cut
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        ctx.fill();

        // Feather edge ~2px using a soft stroke
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx + 1, ry + 1, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      ctx.globalCompositeOperation = 'source-over';
      ctx.restore();
    }

    // Debug overlay (after garment render)
    if (this._debugMode) {
      this.renderDebug(ctx);
    }
  }

  // ── Private ────────────────────────────────────────────────

  private allocateBuffers(topo: Topology): void {
    const n = topo.totalVerts * 2;
    this.srcBuf = new Float32Array(n);
    this.dstBuf = new Float32Array(n);
    this.prevDstBuf = new Float32Array(n);
  }

  /**
   * Render triangle with texture density clamping (Step 5).
   * If local stretch exceeds MAX_STRETCH_RATIO, vertices are pulled
   * inward to prevent texture elongation.
   */
  private renderTriClamped(
    ctx: CanvasRenderingContext2D,
    tex: HTMLCanvasElement | HTMLImageElement,
    s0x: number, s0y: number, s1x: number, s1y: number, s2x: number, s2y: number,
    d0x: number, d0y: number, d1x: number, d1y: number, d2x: number, d2y: number,
  ): void {
    // Skip inverted/degenerate
    const dstArea = (d1x - d0x) * (d2y - d0y) - (d2x - d0x) * (d1y - d0y);
    if (dstArea < 0.5) return;

    // Step 5: Texture density preservation
    const srcArea = Math.abs((s1x - s0x) * (s2y - s0y) - (s2x - s0x) * (s1y - s0y));
    if (srcArea > 0.01) {
      const stretchRatio = Math.sqrt(dstArea / srcArea);
      if (stretchRatio > MAX_STRETCH_RATIO) {
        // Pull destination triangle toward its centroid to reduce stretch
        const cx = (d0x + d1x + d2x) / 3;
        const cy = (d0y + d1y + d2y) / 3;
        const clampFactor = MAX_STRETCH_RATIO / stretchRatio;
        d0x = cx + (d0x - cx) * clampFactor;
        d0y = cy + (d0y - cy) * clampFactor;
        d1x = cx + (d1x - cx) * clampFactor;
        d1y = cy + (d1y - cy) * clampFactor;
        d2x = cx + (d2x - cx) * clampFactor;
        d2y = cy + (d2y - cy) * clampFactor;
      }
    }

    const denom = s0x * (s1y - s2y) + s1x * (s2y - s0y) + s2x * (s0y - s1y);
    if (Math.abs(denom) < 0.001) return;
    const inv = 1 / denom;

    const dy10 = s1y - s2y, dy20 = s2y - s0y, dy01 = s0y - s1y;
    const dx10 = s2x - s1x, dx20 = s0x - s2x, dx01 = s1x - s0x;
    const cr = s1x * s2y - s2x * s1y;
    const cr2 = s2x * s0y - s0x * s2y;
    const cr3 = s0x * s1y - s1x * s0y;

    const a = (d0x * dy10 + d1x * dy20 + d2x * dy01) * inv;
    const b = (d0y * dy10 + d1y * dy20 + d2y * dy01) * inv;
    const c = (d0x * dx10 + d1x * dx20 + d2x * dx01) * inv;
    const d = (d0y * dx10 + d1y * dx20 + d2y * dx01) * inv;
    const e = (d0x * cr + d1x * cr2 + d2x * cr3) * inv;
    const f = (d0y * cr + d1y * cr2 + d2y * cr3) * inv;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(d0x, d0y);
    ctx.lineTo(d1x, d1y);
    ctx.lineTo(d2x, d2y);
    ctx.closePath();
    ctx.clip();
    ctx.setTransform(a, b, c, d, e, f);
    ctx.drawImage(tex, 0, 0);
    ctx.restore();
  }

  // ── Step 6: Debug Rendering ─────────────────────────────────

  private renderDebug(ctx: CanvasRenderingContext2D): void {
    const dst = this.dstBuf;
    const { verts, gridSize } = this.topo;
    const sleeveEndRow = Math.ceil(gridSize * this._sleeveEndRow);

    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0); // reset transform

    // Mesh wireframe
    ctx.strokeStyle = 'rgba(0,255,136,0.4)';
    ctx.lineWidth = 0.5;
    for (let row = 0; row < verts; row++) {
      for (let col = 0; col < verts; col++) {
        const bi = (row * verts + col) * 2;
        const x = dst[bi], y = dst[bi + 1];

        // Horizontal line to right neighbor
        if (col < gridSize) {
          const ri = (row * verts + col + 1) * 2;
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(dst[ri], dst[ri + 1]);
          ctx.stroke();
        }
        // Vertical line to bottom neighbor
        if (row < gridSize) {
          const di = ((row + 1) * verts + col) * 2;
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(dst[di], dst[di + 1]);
          ctx.stroke();
        }
      }
    }

    // Sleeve region highlight (blue tint on sleeve rows)
    ctx.fillStyle = 'rgba(59,130,246,0.15)';
    for (let row = 0; row <= sleeveEndRow && row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        const a = (row * verts + col) * 2;
        const b2 = (row * verts + col + 1) * 2;
        const c2 = ((row + 1) * verts + col) * 2;
        const d2 = ((row + 1) * verts + col + 1) * 2;
        // Only highlight edge columns (sleeve columns)
        if (col <= 1 || col >= gridSize - 2) {
          ctx.beginPath();
          ctx.moveTo(dst[a], dst[a + 1]);
          ctx.lineTo(dst[b2], dst[b2 + 1]);
          ctx.lineTo(dst[d2], dst[d2 + 1]);
          ctx.lineTo(dst[c2], dst[c2 + 1]);
          ctx.closePath();
          ctx.fill();
        }
      }
    }

    // Vertex dots
    for (let i = 0; i < this.topo.totalVerts; i++) {
      const bi = i * 2;
      const row = Math.floor(i / verts);
      const col = i % verts;
      const isSleeve = row <= sleeveEndRow && (col <= 1 || col >= gridSize - 1);
      const isHem = row >= gridSize - 1;
      ctx.fillStyle = isSleeve ? '#3b82f6' : isHem ? '#f59e0b' : '#00ff88';
      ctx.beginPath();
      ctx.arc(dst[bi], dst[bi + 1], isSleeve || isHem ? 3 : 1.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Grid info label
    ctx.font = '10px monospace';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(
      `mesh: ${gridSize}×${gridSize} | sleeve: ${(this._sleeveEndRow * 100).toFixed(0)}% | hem: ${(this._hemCurvature * 100).toFixed(1)}%`,
      4, 14
    );

    ctx.restore();
  }

  /** Step 1: Compute elbow dampening factor (0..1). Reduces influence when velocity too high. */
  private computeElbowDampen(
    current: { x: number; y: number } | undefined,
    previous: { x: number; y: number } | null
  ): number {
    if (!current || !previous) return 1.0;
    const vel = Math.hypot(current.x - previous.x, current.y - previous.y);
    if (vel < ELBOW_DAMPEN_VELOCITY_THRESHOLD) return 1.0;
    // Smooth falloff: 1.0 at threshold, approaches 0.2 at high velocity
    return Math.max(0.2, ELBOW_DAMPEN_VELOCITY_THRESHOLD / vel);
  }

  /** Fast numeric hash — avoids string alloc */
  private numericHash(p: PoseMeshInput): number {
    // Cantor-style pairing of rounded coords — not perfectly unique but sufficient for change detection
    const r = (v: number) => (v + 0.5) | 0; // fast round-to-int
    return (
      r(p.leftShoulder.x) * 73856093 ^
      r(p.leftShoulder.y) * 19349663 ^
      r(p.rightShoulder.x) * 83492791 ^
      r(p.rightShoulder.y) * 48611 ^
      r(p.leftHip.x) * 39916801 ^
      r(p.leftHip.y) * 479001599 ^
      r(p.rightHip.x) * 6291469 ^
      r(p.rightHip.y) * 2654435761
    ) | 0;
  }
}
