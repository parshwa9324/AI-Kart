'use client';

/**
 * AR Try-On Page — Product Garment Engine
 *
 * - Garment gallery picker (dataset samples)
 * - File upload for custom garments
 * - Garment type selector
 * - Screenshot capture
 */

import { useRef, useEffect, useState, useCallback } from 'react';
import { Engine, type EngineState, type GarmentType } from '@/ar-engine';
import Scene3D from '../../components/ar/Scene3D';

const SAMPLE_GARMENTS = [
  { url: '/garments/3d-assets/free_lowpoly_jacket.glb', label: '3D Jacket', type: 'shirt' as GarmentType },
  { url: '/garments/3d-assets/short_sleeve_t-_shirt.glb', label: '3D T-Shirt', type: 'tshirt' as GarmentType },
  { url: '/garments/canonical/tshirt_white.png', label: 'White T-Shirt', type: 'tshirt' as GarmentType },
  { url: '/garments/canonical/tshirt_black_long.png', label: 'Black Long', type: 'longsleeve' as GarmentType },
];

export default function TryOnPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<EngineState>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [showKeypoints, setShowKeypoints] = useState(false);
  const [fps, setFps] = useState(0);
  const [activeGarment, setActiveGarment] = useState(SAMPLE_GARMENTS[0].url);
  const [changingGarment, setChangingGarment] = useState(false);

  const startEngine = useCallback(async () => {
    if (!canvasRef.current) return;
    if (status === 'initializing') return;

    // Dispose previous
    if (engineRef.current) {
      engineRef.current.dispose();
      engineRef.current = null;
    }

    setStatus('initializing');
    setErrorMsg('');

    try {
      const engine = new Engine({
        canvas: canvasRef.current,
        shirtUrl: activeGarment,
        useMeshWarp: true,
        showKeypoints: false,
        targetFPS: 30,
        demoMode: true,
        onStatusChange: (s, msg) => {
          setStatus(s);
          if (msg) setErrorMsg(msg);
        },
      });

      await engine.init();
      engine.start();
      engineRef.current = engine;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to start AR';
      setErrorMsg(msg);
      setStatus('error');
    }
  }, [status, activeGarment]);

  // Change garment while running
  const selectGarment = useCallback(async (url: string, type?: GarmentType) => {
    setActiveGarment(url);
    if (engineRef.current && status === 'running') {
      setChangingGarment(true);
      try {
        await engineRef.current.changeGarment(url, type);
      } catch { /* silent */ }
      setChangingGarment(false);
    }
  }, [status]);

  // File upload handler
  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !engineRef.current || status !== 'running') return;
    setChangingGarment(true);
    try {
      await engineRef.current.changeGarmentFromFile(file);
      setActiveGarment(file.name);
    } catch { /* silent */ }
    setChangingGarment(false);
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, [status]);

  // Screenshot
  const captureLook = useCallback(() => {
    if (!canvasRef.current) return;
    try {
      const dataUrl = canvasRef.current.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `AI-Kart_Look_${Date.now()}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch { /* canvas tainted */ }
  }, []);

  // FPS poll
  useEffect(() => {
    if (status !== 'running') return;
    const interval = setInterval(() => {
      if (engineRef.current) setFps(engineRef.current.stats.fps);
    }, 500);
    return () => clearInterval(interval);
  }, [status]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (engineRef.current) {
        engineRef.current.dispose();
        engineRef.current = null;
      }
    };
  }, []);

  // Keypoint toggle
  useEffect(() => {
    if (engineRef.current) engineRef.current.showKeypoints = showKeypoints;
  }, [showKeypoints]);

  // Debug mode: press "D" to toggle mesh debug overlay
  useEffect(() => {
    let debugOn = false;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'd' || e.key === 'D') {
        debugOn = !debugOn;
        engineRef.current?.setDebugMode(debugOn);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const isLoading = status === 'initializing';
  const isLive = status === 'running';
  const isIdle = status === 'idle';
  const isError = status === 'error';
  const showCanvas = !isIdle;

  return (
    <main style={styles.main}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>AI-Kart</h1>
        <span style={styles.badge}>Product Try-On</span>
      </div>

      {/* Controls */}
      <div style={styles.controls}>
        {isIdle && (
          <button onClick={startEngine} style={styles.startBtn}>
            <span style={styles.startIcon}>▶</span> Start AR
          </button>
        )}

        {isLoading && (
          <div style={styles.loadingWrap}>
            <div style={styles.spinner} />
            <span style={styles.loadingText}>Loading camera, AI model &amp; garment…</span>
          </div>
        )}

        {isLive && (
          <div style={styles.liveBar}>
            <span style={styles.liveDot} />
            <span style={styles.liveLabel}>LIVE</span>
            <span style={styles.fpsLabel}>{fps} FPS</span>
            {changingGarment && <span style={styles.loadingText}>Switching…</span>}
            <button onClick={captureLook} style={styles.captureBtn}>📸 Capture</button>
            <label style={styles.toggle}>
              <input
                type="checkbox"
                checked={showKeypoints}
                onChange={(e) => setShowKeypoints(e.target.checked)}
                style={styles.checkbox}
              />
              Debug
            </label>
          </div>
        )}

        {isError && (
          <div style={styles.errorWrap}>
            <p style={styles.errorText}>⚠ {errorMsg}</p>
            <button onClick={startEngine} style={styles.retryBtn}>Retry</button>
          </div>
        )}
      </div>

      {/* Main area: canvas + garment panel side-by-side */}
      <div style={styles.mainArea}>
        {/* Canvas */}
        <div style={styles.canvasWrap}>
          <canvas
            ref={canvasRef}
            style={{ ...styles.canvas, display: showCanvas ? 'block' : 'none' }}
          />
          {showCanvas && <Scene3D garmentUrl={activeGarment} />}
          {isIdle && (
            <div style={styles.placeholder}>
              <div style={styles.placeholderIcon}>👕</div>
              <p style={styles.placeholderText}>
                Select a garment below, then click <strong>Start AR</strong>
              </p>
            </div>
          )}
        </div>

        {/* Garment Panel */}
        <div style={styles.garmentPanel}>
          <h3 style={styles.panelTitle}>Select Garment</h3>

          {/* Gallery */}
          <div style={styles.gallery}>
            {SAMPLE_GARMENTS.map((g) => (
              <button
                key={g.url}
                onClick={() => selectGarment(g.url, g.type)}
                style={{
                  ...styles.garmentCard,
                  ...(activeGarment === g.url ? styles.garmentCardActive : {}),
                }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={g.url} alt={g.label} style={styles.garmentImg} />
                <span style={styles.garmentLabel}>{g.label}</span>
              </button>
            ))}
          </div>

          {/* Upload */}
          <div style={styles.uploadSection}>
            <p style={styles.uploadLabel}>Or upload your own:</p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handleFileUpload}
              style={styles.fileInput}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              style={styles.uploadBtn}
            >
              📁 Upload Image
            </button>
            <p style={styles.uploadHint}>
              PNG with transparent background works best.
              JPG/JPEG backgrounds will be auto-removed.
            </p>
          </div>
        </div>
      </div>

      <p style={styles.footer}>
        Powered by MediaPipe Pose • 8×8 Mesh Warping • Client-side AI
      </p>
    </main>
  );
}

// ── Styles ──────────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  main: {
    minHeight: '100vh',
    background: 'linear-gradient(180deg, #0a0a0f 0%, #111118 100%)',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    fontFamily: 'var(--font-geist-sans), system-ui, -apple-system, sans-serif',
    color: '#fff', padding: '1.2rem 1rem', gap: '0.8rem',
  },
  header: { display: 'flex', alignItems: 'center', gap: '0.75rem' },
  title: {
    fontSize: '1.6rem', fontWeight: 800, letterSpacing: '-0.03em',
    background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)',
    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', margin: 0,
  },
  badge: {
    fontSize: '0.7rem', fontWeight: 600, padding: '0.2rem 0.5rem',
    borderRadius: '4px', background: 'rgba(139,92,246,0.2)',
    color: '#a78bfa', textTransform: 'uppercase' as const, letterSpacing: '0.05em',
  },
  controls: { display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 44 },
  startBtn: {
    display: 'flex', alignItems: 'center', gap: '0.5rem',
    padding: '0.7rem 2rem', fontSize: '1rem', fontWeight: 700,
    background: 'linear-gradient(135deg, #2563eb, #7c3aed)', color: '#fff',
    border: 'none', borderRadius: '10px', cursor: 'pointer',
    boxShadow: '0 4px 20px rgba(37,99,235,0.35)',
  },
  startIcon: { fontSize: '0.85rem' },
  loadingWrap: { display: 'flex', alignItems: 'center', gap: '0.6rem' },
  spinner: {
    width: 18, height: 18, border: '2px solid rgba(255,255,255,0.15)',
    borderTopColor: '#3B82F6', borderRadius: '50%', animation: 'spin 0.8s linear infinite',
  },
  loadingText: { color: '#888', fontSize: '0.85rem' },
  liveBar: {
    display: 'flex', alignItems: 'center', gap: '0.5rem',
    padding: '0.35rem 0.8rem', background: 'rgba(255,255,255,0.05)',
    borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)',
    flexWrap: 'wrap' as const,
  },
  liveDot: {
    width: 8, height: 8, borderRadius: '50%',
    background: '#00ff88', boxShadow: '0 0 6px #00ff88',
  },
  liveLabel: { fontSize: '0.75rem', fontWeight: 700, color: '#00ff88', letterSpacing: '0.05em' },
  fpsLabel: { fontSize: '0.8rem', color: '#888', fontFamily: 'monospace' },
  captureBtn: {
    padding: '0.25rem 0.6rem', fontSize: '0.78rem', fontWeight: 600,
    background: 'linear-gradient(135deg, #2563eb, #7c3aed)', color: '#fff',
    border: 'none', borderRadius: '6px', cursor: 'pointer',
    boxShadow: '0 2px 8px rgba(37,99,235,0.3)',
  },
  toggle: {
    fontSize: '0.78rem', color: '#666', display: 'flex',
    alignItems: 'center', gap: '0.25rem', cursor: 'pointer',
  },
  checkbox: { accentColor: '#3B82F6' },
  errorWrap: { display: 'flex', flexDirection: 'column' as const, alignItems: 'center', gap: '0.5rem' },
  errorText: { color: '#ff6b6b', fontSize: '0.9rem', margin: 0 },
  retryBtn: {
    padding: '0.4rem 1rem', background: 'rgba(255,255,255,0.08)', color: '#fff',
    border: '1px solid rgba(255,255,255,0.15)', borderRadius: '6px', cursor: 'pointer', fontSize: '0.85rem',
  },

  // Main area (canvas + panel side by side)
  mainArea: {
    display: 'flex', gap: '1rem', width: '100%', maxWidth: 960,
    alignItems: 'flex-start', flexWrap: 'wrap' as const,
  },
  canvasWrap: {
    position: 'relative' as const, flex: '1 1 480px', minWidth: 320,
    aspectRatio: '4/3',
  },
  canvas: { width: '100%', height: '100%', borderRadius: '12px', background: '#111' },
  placeholder: {
    width: '100%', height: '100%', borderRadius: '12px',
    background: 'rgba(255,255,255,0.03)', border: '1px dashed rgba(255,255,255,0.1)',
    display: 'flex', flexDirection: 'column' as const, alignItems: 'center',
    justifyContent: 'center', gap: '0.5rem',
  },
  placeholderIcon: { fontSize: '2.5rem', opacity: 0.4 },
  placeholderText: { color: '#555', fontSize: '0.9rem', textAlign: 'center' as const },

  // Garment panel
  garmentPanel: {
    flex: '0 0 260px', maxWidth: 300,
    background: 'rgba(255,255,255,0.03)', borderRadius: '12px',
    border: '1px solid rgba(255,255,255,0.06)', padding: '0.8rem',
  },
  panelTitle: {
    margin: '0 0 0.6rem', fontSize: '0.9rem', fontWeight: 700,
    color: '#bbb', letterSpacing: '0.02em',
  },
  gallery: {
    display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.4rem',
  },
  garmentCard: {
    display: 'flex', flexDirection: 'column' as const, alignItems: 'center',
    padding: '0.3rem', background: 'rgba(255,255,255,0.04)', border: '2px solid transparent',
    borderRadius: '8px', cursor: 'pointer', transition: 'all 0.15s',
  },
  garmentCardActive: {
    borderColor: '#7c3aed', background: 'rgba(124,58,237,0.1)',
  },
  garmentImg: {
    width: '100%', aspectRatio: '1', objectFit: 'cover' as const,
    borderRadius: '6px', background: '#1a1a22',
  },
  garmentLabel: {
    fontSize: '0.65rem', color: '#888', marginTop: '0.2rem',
    textAlign: 'center' as const, whiteSpace: 'nowrap' as const,
  },

  // Upload
  uploadSection: { marginTop: '0.8rem', borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '0.6rem' },
  uploadLabel: { fontSize: '0.78rem', color: '#888', margin: '0 0 0.3rem' },
  fileInput: { display: 'none' },
  uploadBtn: {
    width: '100%', padding: '0.5rem', fontSize: '0.82rem', fontWeight: 600,
    background: 'rgba(255,255,255,0.06)', color: '#bbb',
    border: '1px dashed rgba(255,255,255,0.15)', borderRadius: '8px',
    cursor: 'pointer', transition: 'all 0.15s',
  },
  uploadHint: {
    fontSize: '0.68rem', color: '#555', marginTop: '0.3rem', lineHeight: 1.3,
  },

  footer: { color: '#333', fontSize: '0.72rem', marginTop: 'auto', paddingTop: '0.5rem' },
};
