'use client';

import Link from 'next/link';

export default function Home() {
  return (
    <main
      style={{
        minHeight: '100vh',
        background: '#0a0a0a',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-geist-sans), system-ui, sans-serif',
        color: '#fff',
        gap: '2rem',
      }}
    >
      <h1
        style={{
          fontSize: '2.5rem',
          fontWeight: 800,
          letterSpacing: '-0.03em',
          background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}
      >
        AI-Kart
      </h1>
      <p style={{ color: '#888', fontSize: '1.1rem', maxWidth: 400, textAlign: 'center' }}>
        AR-powered virtual clothes try-on. See how clothes look on you in real time.
      </p>
      <Link
        href="/try-on"
        style={{
          padding: '0.8rem 2rem',
          fontSize: '1.1rem',
          fontWeight: 600,
          background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
          color: '#fff',
          border: 'none',
          borderRadius: '10px',
          textDecoration: 'none',
          transition: 'transform 0.15s ease',
        }}
      >
        Try On Now →
      </Link>
    </main>
  );
}
