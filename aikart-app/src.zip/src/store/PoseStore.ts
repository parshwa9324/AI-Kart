import { create } from 'zustand';

export interface Point3D {
    x: number;
    y: number;
    z?: number;
}

export interface PoseState {
    isActive: boolean;
    leftShoulder: Point3D;
    rightShoulder: Point3D;
    leftHip: Point3D;
    rightHip: Point3D;
    leftElbow?: Point3D;
    rightElbow?: Point3D;
    canvasWidth: number;
    canvasHeight: number;
    yawCompression: number;
    torsoPitchScale: number;
    collarY?: number;
    spineLength?: number;
    bodyYawAngle: number;

    // Actions
    updatePose: (data: Partial<PoseState>) => void;
    resetPose: () => void;
}

/**
 * Global store to bridge Vanilla JS AR Engine with React-Three-Fiber.
 * Written to 30 times a second by Engine.ts, read by Scene3D.tsx via useFrame.
 */
export const usePoseStore = create<PoseState>((set) => ({
    isActive: false,
    leftShoulder: { x: 0, y: 0 },
    rightShoulder: { x: 0, y: 0 },
    leftHip: { x: 0, y: 0 },
    rightHip: { x: 0, y: 0 },
    leftElbow: undefined,
    rightElbow: undefined,
    canvasWidth: 640,
    canvasHeight: 480,
    yawCompression: 1.0,
    torsoPitchScale: 1.0,
    collarY: undefined,
    spineLength: undefined,
    bodyYawAngle: 0,

    updatePose: (data) => set((state) => ({ ...state, ...data, isActive: true })),
    resetPose: () => set({ isActive: false })
}));
